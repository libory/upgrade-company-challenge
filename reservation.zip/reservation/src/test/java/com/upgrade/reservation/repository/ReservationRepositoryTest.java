package com.upgrade.reservation.repository;

import static com.upgrade.reservation.util.Helper.MISSING_CUSTOMER_ID;
import static com.upgrade.reservation.util.Helper.SP_MSG_ALREADY_BOOKED;
import static com.upgrade.reservation.util.Helper.SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS;
import static com.upgrade.reservation.util.Helper.SP_MSG_DUPLICATED_KEYS;
import static com.upgrade.reservation.util.Helper.SP_MSG_SUCCESFULL;
import static com.upgrade.reservation.util.Helper.parseDateTime;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.upgrade.reservation.configuration.BeanConfig;
import com.upgrade.reservation.configuration.MySqlConfigForTest;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.dto.impl.OccupancyDtoImpl;
import com.upgrade.reservation.model.Customer;
import com.upgrade.reservation.model.Reservation;
import com.upgrade.reservation.util.TokenGenerator;

@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@ContextConfiguration(classes = {
    MySqlConfigForTest.class,
    BeanConfig.class
})
@Transactional
@TestInstance(Lifecycle.PER_CLASS)
class ReservationRepositoryTest {

    private static final String EMAIL = "abc123@abc.com";
    private static final String EMAIL_ONE = "juan.garcia@abc.com";
    private static final String EMAIL_TWO = "jroberto.fdez@ahgj.org";
    private static final String EMAIL_THREE = "fourz@gt.zw";
    private static final String EMAIL_FIVE = "jfivelao.ramirez@gt.yug";
    private static final String EMAIL_SIX = "sixrez@gt.com";
    private static final String EMAIL_SEVEN = "jbacallseven@gt.rt";
    private static final String EMAIL_EIGHT = "jbeightrez@gt.da";
    private static final String EMAIL_YSEM = "ysemejor@coj.m.mld.cu";
    private static final String NON_EXISTING_TOKEN = "@";
    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";
    private static final String TOKEN = "QSE12DG";
    private static final String ANOTHER_EMAIL = "ggg@ggg.com";
    private static final String ANOTHER_FIRST_NAME = "fn";
    private static final String ANOTHER_LAST_NAME = "ln";
    private static final LocalDate DATE_FOR_JANUARY_FIRST = parseDateTime("2017-01-01");
    private static final LocalDate DATE_FOR_JANUARY_THIRD = parseDateTime("2017-01-03");
    private static final LocalDate DATE_FOR_JANUARY_FIVE = parseDateTime("2017-01-05");
    private static final LocalDate DATE_FOR_JANUARY_EIGHT = parseDateTime("2017-01-08");
    private static final LocalDate DATE_FOR_JANUARY_TWELVE = parseDateTime("2017-01-12");
    private static final LocalDate DATE_FOR_JANUARY_FOURTEEN = parseDateTime("2017-01-14");
    private static final LocalDate DATE_FOR_JANUARY_EIGHTEEN = parseDateTime("2017-01-18");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_ONE = parseDateTime("2017-01-21");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_TWO = parseDateTime("2017-01-22");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_FOUR = parseDateTime("2017-01-24");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_SIX = parseDateTime("2017-01-26");
    private static final String EMAIL_FOR_CREATE = "create@create.com";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ReservationRepository reservationRepositoryForTest;

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    private TokenGenerator tokenGenerator;

    @BeforeEach
    public void setUp() {
        deleteAll();
    }

    @AfterAll
    public void cleaning() {
        deleteAll();
    }

    @Test
    public void givenExistingReservationWhenFindByTokenThenReservationFound() throws Exception {
        // Arrange
        Customer newCustomer = new Customer(EMAIL_ONE, FIRST_NAME, LAST_NAME);
        entityManager.persist(newCustomer);
        Reservation newReservation = new Reservation(TOKEN, newCustomer, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        entityManager.persist(newReservation);
        entityManager.flush();
        // Act
        Optional<Reservation> actualReservationOpt =  reservationRepositoryForTest.findByToken(TOKEN);
        // Assert
        Reservation actualReservation = actualReservationOpt.get();
        assertNotNull(actualReservation.getId());
        assertEquals(TOKEN, actualReservation.getToken());
    }

    @Test
    public void givenNonExistingReservationWhenFindByTokenThenNoReservationFound() throws Exception {
        // Act
        Optional<Reservation> actualReservation =  reservationRepositoryForTest.findByToken(NON_EXISTING_TOKEN);
        // Assert
        assertFalse(actualReservation.isPresent());
    }

    @Test
    @SuppressWarnings("unchecked")
    public void givenRangeDateWhenFindOccupancyByDateRangeThenOccupancyVerified() throws Exception {
        // Arrange
        createCustomersAndReservations("emailqwe@ki.com", "radsa@sld.ru");
        // Act & Assert
        Object[][] paramsAndResultArray = getParametersForFindOccupancyByDateRange();
        for (Object[] paramsAndResult : paramsAndResultArray) {
            final String testName = String.valueOf(paramsAndResult[0]);
            final String fromDate = String.valueOf(paramsAndResult[1]);
            final String toDate = String.valueOf(paramsAndResult[2]);
            final List<OccupancyDto> expectedOccupancies = (List<OccupancyDto>)paramsAndResult[3];
            final List<OccupancyDto> actualOccupancies =
                    reservationRepositoryForTest.findByDateRange(String.valueOf(fromDate), String.valueOf(toDate));
            final AtomicInteger count = new AtomicInteger();
            actualOccupancies.forEach(proxiedItem -> {
                // Note: OccupancyDto is proxied here
                final OccupancyDtoImpl actualOccupancy = new OccupancyDtoImpl();
                actualOccupancy.setFromDate(proxiedItem.getFromDate());
                actualOccupancy.setToDate(proxiedItem.getToDate());
                if (!expectedOccupancies.contains(actualOccupancy)) {
                    fail(new StringBuffer(actualOccupancy.toString())
                            .append(" was not found.")
                            .append(testName)
                            .toString());
                }
                count.incrementAndGet();
            });
            assertEquals(expectedOccupancies.size(), count.get(), testName);
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void givenDateRangeWhenExistsOccupancyByDateRangeThenCountVerified() throws Exception {
        // Arrange
        createCustomersAndReservations("slq45@ki.org", "ttt@aa.sld.cr");
        final List<Executable> asserts = new ArrayList<>();
        // Act & Assert
        Object[][] paramsAndResultArray = getParametersForFindOccupancyByDateRange();
        for (Object[] paramsAndResult : paramsAndResultArray) {
            final String testName = String.valueOf(paramsAndResult[0]);
            final String fromDate = String.valueOf(paramsAndResult[1]);
            final String toDate = String.valueOf(paramsAndResult[2]);
            final int expectedCount = ((List<OccupancyDto>)paramsAndResult[3]).size();
            final int actualCount =
                    reservationRepositoryForTest.existsOccupancyByDateRange(String.valueOf(fromDate),
                            String.valueOf(toDate), MISSING_CUSTOMER_ID);
            asserts.add(() -> assertEquals(expectedCount, actualCount, testName));
        }
        assertAll(asserts);
    }

    @Test
    public void givenFullReservationInfoWhenCreateThenResponseVerified() throws Exception {
        // Arrange
        long[] ids = createCustomersAndReservations();
        final List<Executable> asserts = new ArrayList<>();
        // Act & Assert
        String[][] paramsAndResultArray = getParametersForCreate(ids);
        for (String[] paramsAndResult : paramsAndResultArray) {
            final String testName = paramsAndResult[0];
            final long customerId = Long.valueOf(paramsAndResult[1]);
            final String email = paramsAndResult[2];
            final String firstName = paramsAndResult[3];
            final String lastName = paramsAndResult[4];
            final String startDate = paramsAndResult[5];
            final String endDate = paramsAndResult[6];
            final String token = paramsAndResult[7];
            final String expectedResult = paramsAndResult[8];
            final String actualResult =
                    reservationRepositoryForTest.create(customerId, email, firstName, lastName, startDate,
                            endDate, token);
            asserts.add(() -> assertEquals(expectedResult, actualResult, testName));
        }
        assertAll(asserts);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest
    @MethodSource("getParametersForUpdateWithInexistentCustomer")
    public void givenReservationWithInexistentCustomerWhenUpdateThenResponseVerified(String testName, String email,
            String firstName, String lastName, String startDate, String endDate)
                    throws Exception {
        // Arrange
        long[] ids = createCustomersAndReservations(EMAIL_TWO, EMAIL_THREE);
        final long reservationId = ids[1];
        final long customerId = -1L;
        // Act & Assert
        reservationRepositoryForTest.update(customerId, reservationId, email, firstName,
                lastName, startDate, endDate);
        Optional<Customer> actualCustomer = customerRepository.findByEmail(email);
        assertFalse(actualCustomer.isPresent());
    }

    @ParameterizedTest
    @MethodSource("getParametersForUpdate")
    public void givenReservationInfoWhenUpdateThenResponseVerified(String testName, String email,
            String firstName, String lastName, String startDate, String endDate, String expectedResult,
            String anotherEmail, String yetAnotherEmail) throws Exception {
        // Arrange
        long[] ids = createCustomersAndReservations(email, anotherEmail);
        final long reservationId = ids[1];
        final long customerId = ids[0];
        // Act & Assert
        String paramEmail = (StringUtils.isEmpty(yetAnotherEmail)) ? email : yetAnotherEmail;
        final String actualResult = reservationRepositoryForTest.update(customerId, reservationId, paramEmail, firstName,
                lastName, startDate, endDate);
            assertEquals(expectedResult, actualResult, testName);
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[][] getParametersForUpdateWithInexistentCustomer() {

        return new String[][] {
            {"Test1", "new@new.com", "hello11", "hello22", "2017-01-03", "2017-01-04"},
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[][] getParametersForUpdate() {

        return new String[][] {
            // success
            {"Test1", EMAIL_FIVE, "hello11", "hello22", "2017-01-03", "2017-01-04", SP_MSG_SUCCESFULL,
                "a" + EMAIL_FIVE, null},
            {"Test2", EMAIL_SIX, "hello111", "hello222", "2017-01-03", "2017-01-04", SP_MSG_SUCCESFULL,
                "b" + EMAIL_SIX, null},
            // success
            {"Test3", EMAIL_SEVEN, "hello4", "hello4", "2017-01-15", "2017-01-16", SP_MSG_SUCCESFULL,
                "c" + EMAIL_SEVEN, null},
            // SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS
            {"Test4", EMAIL_EIGHT, "hello5", "hello5", "2017-01-24", "2017-01-24",
                SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS, "d" + EMAIL_FIVE, null},
            {"Test5", ANOTHER_EMAIL, "hello11", "hello22", "2017-01-03", "2017-01-04", SP_MSG_DUPLICATED_KEYS,
                EMAIL_YSEM, EMAIL_YSEM}
        };
    }

    private String[][] getParametersForCreate(long[] ids) {
        return new String[][] {
            // new reservation with no occupied days
            {"Test1", "-1", EMAIL_FOR_CREATE, "hello1", "hello2", "2017-01-08", "2017-01-09",
                tokenGenerator.bothify(), SP_MSG_SUCCESFULL},
            // try to save same reservation above then error
            {"Test2", "-1", EMAIL_FOR_CREATE, "hello1", "hello2", "2017-01-08", "2017-01-09",
                    tokenGenerator.bothify(), SP_MSG_ALREADY_BOOKED},
            // Existing Customer with new reservation with no occupied days
            {"Test4", String.valueOf(ids[0]), EMAIL, "hello11", "hello22", "2017-01-03", "2017-01-04",
                        tokenGenerator.bothify(), SP_MSG_SUCCESFULL},
            // Existing Customer trying to save same reservation above then error
            {"Test5", String.valueOf(ids[0]), EMAIL, "hello11", "hello22", "2017-01-03", "2017-01-04",
                        tokenGenerator.bothify(), SP_MSG_ALREADY_BOOKED},
            // Existing Customer with an overlapped reservation
            {"Test6", String.valueOf(ids[0]), EMAIL, "hello11", "hello22", "2017-01-04", "2017-01-06",
                        tokenGenerator.bothify(), SP_MSG_ALREADY_BOOKED},
        };
    }

    private long[] createCustomersAndReservations() {
        return createCustomersAndReservations(EMAIL, ANOTHER_EMAIL);
    }

    private long[] createCustomersAndReservations(String email, String anotherEmail) {
        final Customer newCustomer = new Customer(email, FIRST_NAME, LAST_NAME);
        entityManager.persist(newCustomer);
        Customer anotherNewCustomer = new Customer(anotherEmail, ANOTHER_FIRST_NAME, ANOTHER_LAST_NAME);
        entityManager.persist(anotherNewCustomer);

        Reservation newReservation = new Reservation(tokenGenerator.bothify(), newCustomer, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        entityManager.persist(newReservation);
        newCustomer.addReservation(newReservation);
        // Note: these two Ids are bounded
        Long idNewCustomer = newCustomer.getId();
        Long idNewReservation = newReservation.getId();
        newReservation = new Reservation(tokenGenerator.bothify(), newCustomer, DATE_FOR_JANUARY_FIVE,
                DATE_FOR_JANUARY_EIGHT);
        entityManager.persist(newReservation);
        newCustomer.addReservation(newReservation);
        newReservation = new Reservation(tokenGenerator.bothify(), anotherNewCustomer, DATE_FOR_JANUARY_TWELVE,
                DATE_FOR_JANUARY_FOURTEEN);
        entityManager.persist(newReservation);
        anotherNewCustomer.addReservation(newReservation);
        newReservation = new Reservation(tokenGenerator.bothify(), anotherNewCustomer, DATE_FOR_JANUARY_EIGHTEEN,
                DATE_FOR_JANUARY_TWENTY_ONE);
        entityManager.persist(newReservation);
        anotherNewCustomer.addReservation(newReservation);
        newReservation = new Reservation(tokenGenerator.bothify(), newCustomer, DATE_FOR_JANUARY_TWENTY_TWO,
                DATE_FOR_JANUARY_TWENTY_FOUR);
        entityManager.persist(newReservation);
        newCustomer.addReservation(newReservation);
        newReservation = new Reservation(tokenGenerator.bothify(), newCustomer, DATE_FOR_JANUARY_TWENTY_FOUR,
                DATE_FOR_JANUARY_TWENTY_SIX);
        entityManager.persist(newReservation);
        newCustomer.addReservation(newReservation);
        entityManager.flush();
        return new long[] {idNewCustomer, idNewReservation};
    }

    private static Object[][] getParametersForFindOccupancyByDateRange() {
        final OccupancyDto occupancyFromFirstThruThird =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_FIRST, DATE_FOR_JANUARY_THIRD);
        final OccupancyDto occupancyFromFiveThruEight =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_FIVE, DATE_FOR_JANUARY_EIGHT);
        final OccupancyDto occupancyFromTwelveThruFourteen =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWELVE, DATE_FOR_JANUARY_FOURTEEN);
        final OccupancyDto occupancyFromEighteenThruTwentyOne =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_EIGHTEEN, DATE_FOR_JANUARY_TWENTY_ONE);
        final OccupancyDto occupancyFromTwentyTwoThruTwentyFour =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_TWO, DATE_FOR_JANUARY_TWENTY_FOUR);
        final OccupancyDto occupancyFromTwentyFourThruTwentySix =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_FOUR, DATE_FOR_JANUARY_TWENTY_SIX);
        return new Object[][] {
           {
               "Test1",
                "2016-12-01",
                "2016-12-31",
                Collections.emptyList()
            },
            {
                "Test2",
                "2017-01-01",
                "2017-01-31",
                Arrays.asList(
                    occupancyFromFirstThruThird,
                    occupancyFromFiveThruEight,
                    occupancyFromTwelveThruFourteen,
                    occupancyFromEighteenThruTwentyOne,
                    occupancyFromTwentyTwoThruTwentyFour,
                    occupancyFromTwentyFourThruTwentySix
                )
            },
            {
                "Test3",
                "2017-01-02",
                "2017-01-06",
                Arrays.asList(
                    occupancyFromFirstThruThird,
                    occupancyFromFiveThruEight
                )
            },
            {
                "Test4",
                "2017-01-03",
                "2017-01-04",
                Collections.emptyList()
            },
            {
                "Test5",
                "2017-01-04",
                "2017-01-04",
                Collections.emptyList()
            },
            {
                "Test6",
                "2017-01-05",
                "2017-01-06",
                Arrays.asList(
                    occupancyFromFiveThruEight
                )
            },
            {
                "Test7",
                "2017-01-05",
                "2017-01-05",
                Arrays.asList(
                    occupancyFromFiveThruEight
                )
            },
            {
                "Test8",
                "2017-01-14",
                "2017-01-14",
                Collections.emptyList()
            },
            {
                "Test9",
                "2017-01-08",
                "2017-01-12",
                Arrays.asList(
                     occupancyFromTwelveThruFourteen
                )
            },
            {
                "Test10",
                "2017-01-24",
                "2017-01-24",
                Arrays.asList(
                     occupancyFromTwentyFourThruTwentySix
                )
            }
        };
    }

    private void deleteAll() {
        reservationRepositoryForTest.findAll().forEach(r -> reservationRepositoryForTest.delete(r));
        customerRepository.findAll().forEach(r -> customerRepository.delete(r));
    }
}
