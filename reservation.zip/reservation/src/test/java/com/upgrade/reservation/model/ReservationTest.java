package com.upgrade.reservation.model;

import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;
import org.junit.jupiter.api.Test;
import pl.pojo.tester.api.assertion.Method;

public class ReservationTest {

    @Test
    public void shouldPassEqualsAndHashCode() throws Exception {
        // Arrange
        final Class<?> classUnderTest = Reservation.class;

        // Act & Assert
        assertPojoMethodsFor(classUnderTest)
                .testing(Method.EQUALS)
                .testing(Method.HASH_CODE)
                .areWellImplemented();
    }

}
