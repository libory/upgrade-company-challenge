package com.upgrade.reservation.service.impl;

import static com.upgrade.reservation.util.Helper.MAX_DAYS_TO_BOOK;
import static com.upgrade.reservation.util.Helper.MISSING_CUSTOMER_ID;
import static com.upgrade.reservation.util.Helper.formatDateTime;
import static com.upgrade.reservation.util.Helper.parseDateTime;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import com.upgrade.reservation.configuration.BeanConfig;
import com.upgrade.reservation.dto.CustomerDto;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.CustomerDtoImpl;
import com.upgrade.reservation.dto.impl.OccupancyDtoImpl;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;
import com.upgrade.reservation.exception.ReservationException;
import com.upgrade.reservation.model.Customer;
import com.upgrade.reservation.model.Reservation;
import com.upgrade.reservation.repository.CustomerRepository;
import com.upgrade.reservation.repository.ReservationRepository;
import com.upgrade.reservation.util.Holder;
import com.upgrade.reservation.util.TokenGenerator;

@ExtendWith({
    MockitoExtension.class
})
class CampSiteReservationServiceImplTest {

    private static final int MIN_DAYS_A_MONTH_CAN_HAVE = 28;
    private static final String STRING_FOR_JANUARY_FIRST = "2017-01-01";
    private static final String STRING_FOR_JANUARY_THIRD = "2017-01-03";
    private static final String STRING_FOR_JANUARY_FIVE = "2017-01-05";
    private static final String STRING_FOR_JANUARY_TWENTY_ONE = "2017-01-21";
    private static final String STRING_FOR_JANUARY_TWENTY_SIX = "2017-01-26";
    private static final LocalDate DATE_FOR_JANUARY_FIRST = parseDateTime(STRING_FOR_JANUARY_FIRST);
    private static final LocalDate DATE_FOR_JANUARY_THIRD = parseDateTime(STRING_FOR_JANUARY_THIRD);
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_TWO = parseDateTime("2017-01-22");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_FOUR = parseDateTime("2017-01-24");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_SIX = parseDateTime(STRING_FOR_JANUARY_TWENTY_SIX);
    private static final String EMAIL = "abc@abc.com";
    private static final String NON_EXISTING_TOKEN = "@";
    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";
    private static final String TOKEN = "QSE12DG";
    private static final long ID = 1L;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private TokenGenerator tokenGenerator;

    private ModelMapper modelMapper;

    private CampSiteReservationServiceImpl campSiteReservationServiceToTest;

    @BeforeEach
    public void setUp() {
        modelMapper = new BeanConfig().modelMapper();
        campSiteReservationServiceToTest = new CampSiteReservationServiceImpl(customerRepository,
                reservationRepository, tokenGenerator, modelMapper);
    }

    @Test
    void givenStartDateGreaterThanEndDateWhenGetDatesAvailabilityThenExceptionThrown() throws Exception {
        // Arrange
        String startDate = formatDateTime(LocalDate.now());
        String endDate = formatDateTime(LocalDate.now().minus(1l, ChronoUnit.DAYS));
        // Act and Assert
        ReservationException thrownException = assertThrows(ReservationException.class,
                () -> campSiteReservationServiceToTest.getDatesAvailability(startDate, endDate));
        final String expectedErrorMsg = "Start date should be prior to End Date.";
        assertEquals(expectedErrorMsg, thrownException.getMessage());
    }

    @ParameterizedTest
    @MethodSource("getParametersForGetDatesAvailability")
    void givenNullDatesWhenGetDatesAvailabilityThenResultVerified(Object startDate, Object endDate)
            throws Exception {
        // Arrange
        when(reservationRepository.findByDateRange(anyString(), anyString())).thenReturn(Collections.emptyList());
        // Act and Assert
        final List<String> actualResult = campSiteReservationServiceToTest.getDatesAvailability((String) startDate,
                (String) endDate);
        assertThat(actualResult.size(), is(greaterThanOrEqualTo(MIN_DAYS_A_MONTH_CAN_HAVE)));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest
    @MethodSource("getValidParametersForGetDatesAvailability")
    void givenValidDatesWhenGetDatesAvailabilityThenResultVerified(Object startDate, Object endDate,
            Object occupancyList, Object expecedResult) throws Exception {
        // Arrange
        when(reservationRepository.findByDateRange(anyString(), anyString()))
            .thenReturn((List<OccupancyDto>) occupancyList);
        // Act and Assert
        final List<String> actualResult = campSiteReservationServiceToTest.getDatesAvailability((String) startDate,
                (String) endDate);
        assertEquals(expecedResult, actualResult);
    }

    @Test
    void givenInvalidTokenWhenGetReservationThenExceptionThrown() throws Exception {
        // Arrange
        when(reservationRepository.findByToken(anyString())).thenReturn(Optional.empty());
        // Act & Assert
        final ReservationException thrownException = assertThrows(ReservationException.class,
                () -> campSiteReservationServiceToTest.getReservation(NON_EXISTING_TOKEN));
        final String expectedErrorMsg = "No Reservation found for " + NON_EXISTING_TOKEN;
        assertEquals(expectedErrorMsg, thrownException.getMessage());
    }

    @Test
    void givenValidTokenWhenGetReservationThenResultVerified() throws Exception {
        // Arrange
        final Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        final Reservation reservation = new Reservation(TOKEN, customer, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        reservation.setId(111L);
        when(reservationRepository.findByToken(anyString())).thenReturn(Optional.of(reservation));
        final ReservationDto expectedResult =  modelMapper.map(reservation, ReservationDtoImpl.class);
        // Act
        final ReservationDto actualResult = campSiteReservationServiceToTest.getReservation(TOKEN);
        // Assert
        assertEquals(expectedResult, actualResult);
    }

    @Test
    void givenValidEmailWhenGetThenResultVerified() throws Exception {
        // Arrange
        final Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        customer.setId(689L);
        final Reservation reservation = new Reservation(TOKEN, customer, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        reservation.setId(111L);
        customer.addReservation(reservation);
        final CustomerDto expectedResult =  modelMapper.map(customer, CustomerDtoImpl.class);
        when(customerRepository.findByEmail(anyString())).thenReturn(Optional.of(customer));
        // Act
        CustomerDto actualResult = campSiteReservationServiceToTest.get(EMAIL);
        // Assert
        assertEquals(expectedResult, actualResult);
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest
    @MethodSource("getInValidParametersForCancel")
    void givenInValidParametersWhenCancelThenException(Object parameter, Object expectedResult) throws Exception {
        // Act & Assert
        ReservationException thrownException = assertThrows(ReservationException.class,
                () -> campSiteReservationServiceToTest.cancel((Holder<List<ReservationDtoImpl>>) parameter));
        assertEquals(expectedResult, thrownException.getMessage());
    }

    @Test
    void givenValidParametersWhenCancelThenResultVerified() throws Exception {
        // Arrange
        ReservationDtoImpl reservationDto = new ReservationDtoImpl(ID, TOKEN, STRING_FOR_JANUARY_FIRST,
                STRING_FOR_JANUARY_THIRD);
        Reservation reservation = new Reservation(TOKEN, null, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        Holder<List<ReservationDtoImpl>> holder = new Holder<>(Arrays.asList(reservationDto));
        when(reservationRepository.findById(ID)).thenReturn(Optional.of(reservation));
        // Act
        campSiteReservationServiceToTest.cancel(holder);
        // Assert
        verify(reservationRepository, times(1)).delete(reservation);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void givenValidParametersWhenCreateThenResultVerified() throws Exception {
        // Arrange
        final LocalDate rawStartDate = LocalDate.now().plus(2L, ChronoUnit.DAYS);
        final String endDate = formatDateTime(rawStartDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS));
        final String startDate = formatDateTime(rawStartDate);

        final ReservationDto reservationDto = new ReservationDtoImpl(null, TOKEN, startDate, endDate);
        final CustomerDto customerDto = new CustomerDtoImpl(EMAIL, FIRST_NAME, LAST_NAME);
        customerDto.setReservations(new HashSet(Arrays.asList(reservationDto)));
        when(tokenGenerator.bothify()).thenReturn(TOKEN);
        // Act
        campSiteReservationServiceToTest.create(customerDto);
        // Assert
        verify(reservationRepository, times(1)).create(MISSING_CUSTOMER_ID, EMAIL, FIRST_NAME, LAST_NAME, startDate,
                endDate, TOKEN);

    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    void givenValidParametersWhenUpdateThenResultVerified() throws Exception {
        // Arrange
        final LocalDate rawStartDate = LocalDate.now().plus(2L, ChronoUnit.DAYS);
        final String endDate = formatDateTime(rawStartDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS));
        final String startDate = formatDateTime(rawStartDate);

        final ReservationDto reservationDto = new ReservationDtoImpl(null, TOKEN, startDate, endDate);
        reservationDto.setId(ID);
        final CustomerDto customerDto = new CustomerDtoImpl(EMAIL, FIRST_NAME, LAST_NAME);
        customerDto.setId(ID);
        customerDto.setReservations(new HashSet(Arrays.asList(reservationDto)));

        final Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        customer.setId(ID);
        final Reservation reservation = new Reservation(TOKEN, customer, DATE_FOR_JANUARY_FIRST,
                DATE_FOR_JANUARY_THIRD);
        reservation.setId(ID);

        when(customerRepository.findByEmail(EMAIL)).thenReturn(Optional.of(customer));
        when(reservationRepository.findById(ID)).thenReturn(Optional.of(reservation));
        // Act
        campSiteReservationServiceToTest.modify(customerDto, EMAIL);
        // Assert
        verify(reservationRepository, times(1)).update(ID, ID, EMAIL, FIRST_NAME, LAST_NAME, startDate,
                endDate);
    }

    /* Note: this is actually used as @MethodSource*/
    private static Object[][] getInValidParametersForCancel() {
       List<ReservationDto> reservations = null;
       Holder<List<ReservationDto>> holder = new Holder<>(reservations);
       reservations = Arrays.asList(new ReservationDtoImpl());
       Holder<List<ReservationDto>> anotherHolder = new Holder<>(reservations);
        return new Object[][] {
            {
                holder,
                "Reservation(s) to Delete is(are) missing."
            },
            {
                anotherHolder,
                "Bad token or Reservation Id"
            }
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static Object[][] getValidParametersForGetDatesAvailability() {
        final OccupancyDto occupancyFromFirstThruThird =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_FIRST, DATE_FOR_JANUARY_THIRD);
        final OccupancyDto occupancyFromTwentyTwoThruTwentyFour =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_TWO, DATE_FOR_JANUARY_TWENTY_FOUR);
        final OccupancyDto occupancyFromTwentyFourThruTwentySix =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_FOUR, DATE_FOR_JANUARY_TWENTY_SIX);

        return new Object[][] {
            {
                STRING_FOR_JANUARY_FIRST,
                STRING_FOR_JANUARY_FIVE,
                Arrays.asList(occupancyFromFirstThruThird),
                Arrays.asList(STRING_FOR_JANUARY_THIRD, "2017-01-04", STRING_FOR_JANUARY_FIVE)
            },
            {
                STRING_FOR_JANUARY_TWENTY_ONE,
                STRING_FOR_JANUARY_TWENTY_SIX,
                Arrays.asList(occupancyFromTwentyTwoThruTwentyFour, occupancyFromTwentyFourThruTwentySix),
                Arrays.asList(STRING_FOR_JANUARY_TWENTY_ONE, STRING_FOR_JANUARY_TWENTY_SIX)
            }
        };

    }

    /* Note: this is actually used as @MethodSource*/
    private static Object[][] getParametersForGetDatesAvailability() {
        return new Object[][] {
            {
                null,
                STRING_FOR_JANUARY_THIRD

            },
            {
                STRING_FOR_JANUARY_THIRD,
                null
            },

        };
    }

}
