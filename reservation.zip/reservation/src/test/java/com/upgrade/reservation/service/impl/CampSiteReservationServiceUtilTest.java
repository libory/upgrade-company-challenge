package com.upgrade.reservation.service.impl;

import static com.upgrade.reservation.util.Helper.MAX_DAYS_TO_BOOK;
import static com.upgrade.reservation.util.Helper.MAX_MONTHS_AHEAD_ARRIVAL;
import static com.upgrade.reservation.util.Helper.MIN_DAYS_AHEAD_ARRIVAL;
import static com.upgrade.reservation.util.Helper.formatDateTime;
import static com.upgrade.reservation.util.Helper.parseDateTime;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.OccupancyDtoImpl;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;

class CampSiteReservationServiceUtilTest {

    private static final LocalDate DATE_FOR_JANUARY_FIRST = parseDateTime("2017-01-01");
    private static final LocalDate DATE_FOR_JANUARY_THIRD = parseDateTime("2017-01-03");
    private static final LocalDate DATE_FOR_JANUARY_FIVE = parseDateTime("2017-01-05");
    private static final LocalDate DATE_FOR_JANUARY_EIGHT = parseDateTime("2017-01-08");
    private static final LocalDate DATE_FOR_JANUARY_TWELVE = parseDateTime("2017-01-12");
    private static final LocalDate DATE_FOR_JANUARY_FOURTEEN = parseDateTime("2017-01-14");
    private static final LocalDate DATE_FOR_JANUARY_SIXTEEN = parseDateTime("2017-01-16");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_ONE = parseDateTime("2017-01-21");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_TWO = parseDateTime("2017-01-22");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_FOUR = parseDateTime("2017-01-24");
    private static final LocalDate DATE_FOR_JANUARY_TWENTY_SIX = parseDateTime("2017-01-26");

    @ParameterizedTest
    @MethodSource("getInvalidParametersForValidateMaxDaysToBook")
    void givenInvalidReservationWhenValidateMaxDaysToBookThenExceptionThrown(ReservationDto reservationDto) {
        // Act and Assert
        assertThrows(RuntimeException.class,
                () -> CampSiteReservationServiceUtil.validateMaxDaysToBook(reservationDto));
    }

    @ParameterizedTest
    @MethodSource("getValidParametersForValidateMaxDaysToBook")
    void givenValidReservationWhenValidateMaxDaysToBookThenResultVerified(ReservationDto reservationDto) {
        // Act and Assert
        try {
            CampSiteReservationServiceUtil.validateMaxDaysToBook(reservationDto);
        } catch(Exception e) {
            fail(e.getMessage());
        }
    }

    @ParameterizedTest
    @MethodSource("getInvalidParametersForValidateMinAndMaxDaysAhead")
    void givenBadReservationWhenValidateMinAndMaxDaysAheadThenExceptionThrown(ReservationDto reservationDto) {
        // Act and Assert
        assertThrows(RuntimeException.class,
                () -> CampSiteReservationServiceUtil.validateMinAndMaxDaysAheadReservation(reservationDto));
    }

    @ParameterizedTest
    @MethodSource("getValidParametersForValidateMinAndMaxDaysAhead")
    void givenGoodReservationWhenValidateMinAndMaxDaysAheadThenResultVerified(ReservationDto reservationDto) {
        // Act and Assert
        try {
            CampSiteReservationServiceUtil.validateMinAndMaxDaysAheadReservation(reservationDto);
        } catch(Exception e) {
            fail(e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest
    @MethodSource("getInvalidParametersForFindFreeDate")
    void givenInvalidParametersWhenFindFreeDateThenExceptionThrown(Object index, Object occupancies, Object fromDate) {
        // Act and Assert
        assertThrows(RuntimeException.class,
                () -> CampSiteReservationServiceUtil.findFreeDate((int) index, (List<OccupancyDto>) occupancies,
                        (LocalDate)fromDate));
    }

    @SuppressWarnings("unchecked")
    @ParameterizedTest
    @MethodSource("getValidParametersForFindFreeDate")
    void givenValidParametersWhenFindFreeDateThenExceptionThrown(Object index, Object occupancies, Object fromDate,
            Object expectedResult) {
        // Act and Assert
        Optional<String> actualResult = CampSiteReservationServiceUtil.findFreeDate((int)index,
                (List<OccupancyDto>)occupancies, (LocalDate)fromDate);
        assertEquals(expectedResult, actualResult);
    }

    /* Note: this is actually used as @MethodSource*/
    private static Object[][] getValidParametersForFindFreeDate() {
        final OccupancyDto occupancyFromFirstThruThird =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_FIRST, DATE_FOR_JANUARY_THIRD);
        final OccupancyDto occupancyFromFiveThruEight =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_FIVE, DATE_FOR_JANUARY_EIGHT);
        final OccupancyDto occupancyFromTwelveThruFourteen =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWELVE, DATE_FOR_JANUARY_FOURTEEN);
        final OccupancyDto occupancyFromSixteenThruTwentyOne =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_SIXTEEN, DATE_FOR_JANUARY_TWENTY_ONE);
        final OccupancyDto occupancyFromTwentyTwoThruTwentyFour =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_TWO, DATE_FOR_JANUARY_TWENTY_FOUR);
        final OccupancyDto occupancyFromTwentyFourThruTwentySix =
                new OccupancyDtoImpl(DATE_FOR_JANUARY_TWENTY_FOUR, DATE_FOR_JANUARY_TWENTY_SIX);

        return new Object[][] {
            {
                0,
                Collections.emptyList(),
                LocalDate.now(),
                Optional.of(formatDateTime(LocalDate.now()))
            },
            {
                0,
                Arrays.asList(occupancyFromFirstThruThird),
                DATE_FOR_JANUARY_FIRST,
                Optional.empty()
            },
            {
                1,
                Arrays.asList(occupancyFromFirstThruThird),
                DATE_FOR_JANUARY_FIRST,
                Optional.empty()
            },
            {
                2,
                Arrays.asList(occupancyFromFirstThruThird),
                DATE_FOR_JANUARY_FIRST,
                Optional.of(formatDateTime(DATE_FOR_JANUARY_THIRD))
            },
            {
                4,
                Arrays.asList(occupancyFromFirstThruThird),
                DATE_FOR_JANUARY_FIRST,
                Optional.of(formatDateTime(DATE_FOR_JANUARY_FIVE))
            },
            {
                5,
                Arrays.asList(occupancyFromFirstThruThird, occupancyFromFiveThruEight),
                DATE_FOR_JANUARY_FIRST,
                Optional.empty()
            },
            {
                2,
                Arrays.asList(occupancyFromTwentyTwoThruTwentyFour, occupancyFromTwentyFourThruTwentySix),
                DATE_FOR_JANUARY_TWENTY_TWO,
                Optional.empty()
            },
            {
                0,
                Arrays.asList(occupancyFromTwelveThruFourteen, occupancyFromSixteenThruTwentyOne),
                DATE_FOR_JANUARY_FOURTEEN,
                Optional.of(formatDateTime(DATE_FOR_JANUARY_FOURTEEN))
            },
            {
                1,
                Arrays.asList(occupancyFromTwelveThruFourteen, occupancyFromSixteenThruTwentyOne),
                DATE_FOR_JANUARY_FOURTEEN,
                Optional.of("2017-01-15")
            },
            {
                2,
                Arrays.asList(occupancyFromTwelveThruFourteen, occupancyFromSixteenThruTwentyOne),
                DATE_FOR_JANUARY_FOURTEEN,
                Optional.empty()
            }
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static Object[][] getInvalidParametersForFindFreeDate() {
        return new Object[][] {
            {
                0,
                null,
                LocalDate.now()
            },
            {
                0,
                Collections.emptyList(),
                null
            },

        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static ReservationDto[] getInvalidParametersForValidateMaxDaysToBook() {
        ReservationDto beyondMaxDays = new ReservationDtoImpl();
        beyondMaxDays.setFromDate(formatDateTime(LocalDate.now()));
        beyondMaxDays.setToDate(formatDateTime(
                LocalDate.now().plus(MAX_DAYS_TO_BOOK + 1, ChronoUnit.DAYS)));
        return new ReservationDto[] {
            null,
            new ReservationDtoImpl(),
            beyondMaxDays
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static ReservationDto[] getValidParametersForValidateMaxDaysToBook() {
        ReservationDto lessThanMaxDays = new ReservationDtoImpl();
        lessThanMaxDays.setFromDate(formatDateTime(LocalDate.now()));
        lessThanMaxDays.setToDate(formatDateTime(
                LocalDate.now().plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));
        ReservationDto equalMaxDays = new ReservationDtoImpl();
        equalMaxDays.setFromDate(formatDateTime(LocalDate.now()));
        equalMaxDays.setToDate(formatDateTime(
                LocalDate.now().plus(MAX_DAYS_TO_BOOK, ChronoUnit.DAYS)));
        ReservationDto ceroDays = new ReservationDtoImpl();
        ceroDays.setFromDate(formatDateTime(LocalDate.now()));
        ceroDays.setToDate(ceroDays.getFromDate());
        return new ReservationDto[] {
            lessThanMaxDays,
            equalMaxDays,
            ceroDays
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static ReservationDto[] getInvalidParametersForValidateMinAndMaxDaysAhead() {
        ReservationDto beyondMaxAhead = new ReservationDtoImpl();
        LocalDate fromDate = LocalDate.now().plus(MAX_MONTHS_AHEAD_ARRIVAL + 1, ChronoUnit.DAYS);
        beyondMaxAhead.setFromDate(formatDateTime(fromDate));
        beyondMaxAhead.setToDate(formatDateTime(fromDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));

        ReservationDto lessMinAhead = new ReservationDtoImpl();
        LocalDate fromDateMin = LocalDate.now().plus(MIN_DAYS_AHEAD_ARRIVAL - 1, ChronoUnit.DAYS);
        lessMinAhead.setFromDate(formatDateTime(fromDateMin));
        lessMinAhead.setToDate(formatDateTime(fromDateMin.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));

        return new ReservationDto[] {
            null,
            new ReservationDtoImpl(),
            beyondMaxAhead,
            lessMinAhead
        };
    }

    /* Note: this is actually used as @MethodSource*/
    private static ReservationDto[] getValidParametersForValidateMinAndMaxDaysAhead() {
        ReservationDto lessMaxAhead = new ReservationDtoImpl();
        LocalDate fromDate = LocalDate.now().plus(MAX_MONTHS_AHEAD_ARRIVAL - 1, ChronoUnit.DAYS);
        lessMaxAhead.setFromDate(formatDateTime(fromDate));
        lessMaxAhead.setToDate(formatDateTime(fromDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));

        ReservationDto equalMaxAhead = new ReservationDtoImpl();
        fromDate = LocalDate.now().plus(MAX_MONTHS_AHEAD_ARRIVAL, ChronoUnit.DAYS);
        equalMaxAhead.setFromDate(formatDateTime(fromDate));
        equalMaxAhead.setToDate(formatDateTime(fromDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));

        ReservationDto greaterMinAhead = new ReservationDtoImpl();
        fromDate = LocalDate.now().plus(MIN_DAYS_AHEAD_ARRIVAL + 1, ChronoUnit.DAYS);
        greaterMinAhead.setFromDate(formatDateTime(fromDate));
        greaterMinAhead.setToDate(formatDateTime(fromDate.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS)));

        return new ReservationDto[] {
            lessMaxAhead,
            /*equalMaxAhead,*/
            greaterMinAhead
        };
    }
}
