package com.upgrade.reservation.model;

import static pl.pojo.tester.api.FieldPredicate.exclude;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;
import org.junit.jupiter.api.Test;
import pl.pojo.tester.api.assertion.Method;

public class CustomerTest {

    @Test
    public void shouldPassEqualsAndHashCode() throws Exception {
        // Arrange
        final Class<?> classUnderTest = Customer.class;

        // Act & Assert
        assertPojoMethodsFor(classUnderTest, exclude("reservations"))
                .testing(Method.EQUALS)
                .testing(Method.HASH_CODE)
                .areWellImplemented();
    }

}
