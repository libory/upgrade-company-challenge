package com.upgrade.reservation.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

class TokenGeneratorTest {

    @ParameterizedTest
    @MethodSource("getInvalidPatternForTokenGenerator")
    void givenInvalidPatternWenTokenGeneratorThenExceptionThrown(String invalidPattern) throws Exception {
        final IllegalArgumentException thrownException = assertThrows(IllegalArgumentException.class,
                () -> new TokenGenerator(invalidPattern));
        final String expectedErrorMsg =  ("Bad DefaultPattern value for TokenGenerator.");
        assertEquals(expectedErrorMsg, thrownException.getMessage());
    }

    @Test
    void givenDefaultPatternWenBothifyThenTokenGenerated() throws Exception {
        // Arrange
        TokenGenerator tokenGenerator = new TokenGenerator();
        // Act
        String result = tokenGenerator.bothify();
        // Assert
        assertTrue(Pattern.matches("[a-z][0-9]", result));
    }

    @Test
    void givenNullWenBothifyThenNullVerified() throws Exception {
        // Arrange
        TokenGenerator tokenGenerator = new TokenGenerator();
        // Act
        String result = tokenGenerator.bothify(null);
        // Assert
        assertNull(result);
    }

    @ParameterizedTest
    @MethodSource("getPatternsWithoutPlaceHoldersForBothify")
    void givenPatternWithoutPlaceHolderWenBothifyThenTokenVerified(String pattern, String expectedPattern)
            throws Exception {
        // Arrange
        TokenGenerator tokenGenerator = new TokenGenerator();
        // Act
        String result = tokenGenerator.bothify(pattern);
        // Assert
        assertEquals(expectedPattern, result);
    }

    @ParameterizedTest
    @MethodSource("getPatternsForBothify")
    void givenPatternWenBothifyThenTokenVerified(String pattern, String length, String expectedPattern)
            throws Exception {
        // Arrange
        TokenGenerator tokenGenerator = new TokenGenerator();
        // Act
        String result = tokenGenerator.bothify(pattern);
        // Assert
        assertEquals(Integer.valueOf(length).intValue(), result.length());
        assertTrue(Pattern.matches(expectedPattern, result));
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[] getInvalidPatternForTokenGenerator() {
        return new String[] {" ", "", null};
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[][] getPatternsWithoutPlaceHoldersForBothify() {
        return new String[][] {{"", ""}, {" ", " "}, {"qaz", "qaz"}};
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[][] getPatternsForBothify() {
        return new String[][] {
            {"qaz#", "4", "qaz\\d"},
            {"q#z#", "4", "q\\dz\\d"},
            {"####", "4", "\\d{4}"},
            {"#", "1", "\\d"},
            {" #", "2", " \\d"},
            {"qaz?", "4", ".*[^\\?+].*"},
            {"q?z?", "4", ".*[^\\?+].*"},
            {"????", "4", ".*[^\\?+].*"},
            {"?", "1", ".*[^\\?+].*"},
            {" ?", "2", ".*[^\\?+].*"},
            {"q?z#", "4", "q[a-z]z[0-9]"},
            {"?#?#", "4", "[a-z][0-9][a-z][0-9]"},
            {"#?a", "3", "[0-9][a-z]a"},
            {" ? # ", "5", " [a-z] [0-9] "}
        };
    }
}
