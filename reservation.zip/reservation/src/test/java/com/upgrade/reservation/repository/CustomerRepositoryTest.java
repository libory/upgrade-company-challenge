package com.upgrade.reservation.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.upgrade.reservation.configuration.MySqlConfigForTest;
import com.upgrade.reservation.model.Customer;

@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@ContextConfiguration(classes = MySqlConfigForTest.class)
@Transactional
@TestInstance(Lifecycle.PER_CLASS)
class CustomerRepositoryTest {

    private static final String EMAIL = "abc@abc.com";
    private static final String NON_EXISTING_EMAIL = "test@test.test";
    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private CustomerRepository customerRepositoryForTest;

    @Autowired
    private ReservationRepository reservationRepository;

    @BeforeEach
    public void setUp() {
        deleteAll();
    }

    @AfterAll
    public void cleaning() {
        deleteAll();
    }

    @Test
    public void givenExistingCustomerWhenFindByEmailThenCustomerFound() throws Exception {
        // Arrange
        entityManager.persist(new Customer(EMAIL, FIRST_NAME, LAST_NAME));
        entityManager.flush();
        // Act
        Optional<Customer> actualCustomerOpt =  customerRepositoryForTest.findByEmail(EMAIL);
        // Assert
        Customer actualCustomer = actualCustomerOpt.get();
        assertNotNull(actualCustomer.getId());
        assertEquals(EMAIL, actualCustomer.getEmail());
    }

    @Test
    public void givenNonExistingEmailWhenFindByEmailThenNoCustomerFound() throws Exception {
        // Act
        Optional<Customer> actualCustomer =  customerRepositoryForTest.findByEmail(NON_EXISTING_EMAIL);
        // Assert
        assertFalse(actualCustomer.isPresent());
    }

    private void deleteAll() {
        reservationRepository.findAll().forEach(r -> reservationRepository.delete(r));
        customerRepositoryForTest.findAll().forEach(r -> customerRepositoryForTest.delete(r));
    }

}
