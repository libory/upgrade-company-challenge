package com.upgrade.reservation.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import com.upgrade.reservation.exception.ReservationException;

class HelperTest {

    private static final String VALID_STRING_DATE = "2000-01-01";
    private static final LocalDate VALID_DATE = LocalDate.of(2000, 1, 1);

    @Test
    void givenValidStringDateWhenParseDateTimeThenResultVerified() throws Exception {
        // Arrange & Act
        final LocalDate actualDateTime = Helper.parseDateTime(VALID_STRING_DATE);
        // Assert
        assertEquals(VALID_DATE, actualDateTime);
    }

    @ParameterizedTest
    @MethodSource("getInvalidDatesForParseDateTime")
    void givenInvalidFormattedDatesWhenParseDateTimeThenExceptionThrown(String invalidDate) throws Exception {
        // Act & Assert
        final ReservationException thrownException = assertThrows(ReservationException.class,
                () -> Helper.parseDateTime(invalidDate));
        final String expectedErrorMsg =  "This value '" + invalidDate + "' has a no valid Date format.";
        assertEquals(expectedErrorMsg, thrownException.getMessage());
    }

    @Test
    void givenValidDateWhenFormatDateTimeThenFormattedDateTimeVerified() throws Exception {
        // Arrange & Act
        final String actualFormattedDateTime = Helper.formatDateTime(VALID_DATE);
        // Assert
        assertEquals(VALID_STRING_DATE, actualFormattedDateTime);
    }

    @Test
    void givenNullDateWhenFormatDateTimeThenExceptionThrown() throws Exception {
        // Arrange
        final LocalDate invalidDateTime = null;
        // Act & Assert
        final ReservationException thrownException = assertThrows(ReservationException.class,
                () -> Helper.formatDateTime(invalidDateTime));
        final String expectedErrorMsg =  "This value '" + invalidDateTime + "' is not a valid LocalDate.";
        assertEquals(expectedErrorMsg, thrownException.getMessage());
    }

    /* Note: this is actually used as @MethodSource*/
    private static String[] getInvalidDatesForParseDateTime() {
        return new String[] {"2000-01-01 00:12:40", null, "200"};
    }


}
