package com.upgrade.reservation.controller;

import static com.upgrade.reservation.util.Helper.DEFAULT_TOKEN_PATTERN;
import static com.upgrade.reservation.util.Helper.MAX_DAYS_TO_BOOK;
import static com.upgrade.reservation.util.Helper.SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS;
import static com.upgrade.reservation.util.Helper.SP_MSG_SUCCESFULL;
import static com.upgrade.reservation.util.Helper.SP_MSG_TRY_TO_CREATE_BUT_ALREADY_BOOKED_DAYS;
import static com.upgrade.reservation.util.Helper.formatDateTime;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.upgrade.reservation.dto.CustomerDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.CustomerDtoImpl;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;
import com.upgrade.reservation.model.Customer;
import com.upgrade.reservation.model.Reservation;
import com.upgrade.reservation.repository.CustomerRepository;
import com.upgrade.reservation.repository.ReservationRepository;
import com.upgrade.reservation.util.Holder;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = {"default", "test"})
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestInstance(Lifecycle.PER_CLASS)
class ReservationControllerITAndConcurrencyTest {

    private static final String EMAIL = "controller@abc.com";
    private static final String NEW_EMAIL = "newc@abc.com";
    private static final String ANOTHER_NEW_EMAIL = "latinBbb@olp.cz";
    private static final String FIRST_NAME = "firstName";
    private static final String NEW_FIRST_NAME = "newfirstName";
    private static final String LAST_NAME = "lastName";
    private static final String NEW_LAST_NAME = "newlastName";
    private static final String TOKEN = "QSE12DG";
    private static final String NEW_TOKEN = "1232DG";
    private static final String ANOTHER_NEW_TOKEN = "Z292DZ";
    private static final String ROOT_PATH ="/campsite-api";
    private static final String PUT_CREATE = ROOT_PATH + "/reservation/";
    private static final String POST_UPDATE = ROOT_PATH + "/reservation/";
    private static final String DELETE_CANCEL = ROOT_PATH + "/reservation/";
    private static final LocalDate RAW_START_DATE = LocalDate.now().plus(2L, ChronoUnit.DAYS);
    private static final LocalDate RAW_END_DATE = RAW_START_DATE.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS);
    private static final String START_DATE = formatDateTime(RAW_START_DATE);
    private static final String END_DATE = formatDateTime(RAW_END_DATE);
    private static final LocalDate NEW_RAW_START_DATE = RAW_END_DATE.plus(2L, ChronoUnit.DAYS);
    private static final LocalDate NEW_RAW_END_DATE = NEW_RAW_START_DATE.plus(2L, ChronoUnit.DAYS);
    private static final LocalDate RAW_THIRD_START_DATE = RAW_START_DATE.plus(1L, ChronoUnit.DAYS);
    private static final String THIRD_START_DATE = formatDateTime(RAW_THIRD_START_DATE);
    private static final String THIRD_END_DATE = formatDateTime(RAW_THIRD_START_DATE.plus(MAX_DAYS_TO_BOOK - 1,
            ChronoUnit.DAYS));
    private static final LocalDate RAW_FOURTH_START_DATE = NEW_RAW_END_DATE.plus(10L, ChronoUnit.DAYS);
    private static final LocalDate RAW_FOURTH_END_DATE = RAW_FOURTH_START_DATE.plus(MAX_DAYS_TO_BOOK - 1,
            ChronoUnit.DAYS);
    private static final LocalDate RAW_FITH_START_DATE = RAW_FOURTH_END_DATE.plus(5, ChronoUnit.DAYS);
    private static final LocalDate RAW_FITH_END_DATE = RAW_FITH_START_DATE.plus(MAX_DAYS_TO_BOOK - 1, ChronoUnit.DAYS);
    private static final int HTTP_STATUS_OK = 200;

    @Autowired
    private TestRestTemplate template;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @BeforeEach
    public void setUp() {
        deleteAll();
    }

    @AfterAll
    public void cleaning() {
        deleteAll();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    public void givenValidCustomerAndReservationWhenCreateThenResponseVerified() throws Exception {
        // Arrange
        final ReservationDto reservationDto = new ReservationDtoImpl(null, null, START_DATE, END_DATE);
        final CustomerDto customerDto = new CustomerDtoImpl(EMAIL, FIRST_NAME, LAST_NAME);
        customerDto.setReservations(new HashSet(Arrays.asList(reservationDto)));
        HttpEntity<Object> createBody = getHttpEntity(objectMapper.writeValueAsString(customerDto));
        // Act
        ResponseEntity<List<String>> response = template.exchange(PUT_CREATE, HttpMethod.PUT, createBody,
                new ParameterizedTypeReference<List<String>>() {});
        // Assert
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertEquals(DEFAULT_TOKEN_PATTERN.length(), response.getBody().get(0).length());
    }

    @Test
    public void givenValidCustomerAndReservationWhenUpdateThenResponseVerified() throws Exception {
        // Arrange
        Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        customer = customerRepository.save(customer);
        Reservation reservation = new Reservation(TOKEN, customer, RAW_START_DATE, RAW_END_DATE);
        reservation = reservationRepository.save(reservation);
        customer.addReservation(reservation);
        reservation.setCustomer(null);

        // Setting New values
        customer.setEmail(NEW_EMAIL);
        customer.setFirstName(NEW_FIRST_NAME);
        customer.setLastName(NEW_LAST_NAME);
        reservation.setFromDate(NEW_RAW_START_DATE);
        reservation.setToDate(NEW_RAW_END_DATE);
        HttpEntity<Object> updateBody = getHttpEntity(objectMapper.writeValueAsString(customer));
        // Act
        ResponseEntity<List<String>> response = template.exchange(POST_UPDATE + "?oemail=" + EMAIL, HttpMethod.POST,
                updateBody, new ParameterizedTypeReference<List<String>>() {});
        // Assert
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertEquals(SP_MSG_SUCCESFULL, response.getBody().get(0));
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Test
    public void givenValidCustomerAndReservationWhenCancelThenResponseVerified() throws Exception {
        // Arrange
        Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        customer = customerRepository.save(customer);
        Reservation reservation = new Reservation(TOKEN, customer, RAW_START_DATE, RAW_END_DATE);
        reservation = reservationRepository.save(reservation);
        customer.addReservation(reservation);
        reservation.setCustomer(null);
        HttpEntity<Object> removeBody =
                getHttpEntity(objectMapper.writeValueAsString(new Holder(customer.getReservations())));
        // Act
        ResponseEntity<String> response = template.exchange(DELETE_CANCEL, HttpMethod.DELETE, removeBody, String.class);
        // Assert
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertEquals(SP_MSG_SUCCESFULL, response.getBody());
    }

    @Test
    public void givenValidCustomerAndReservationWhenGetCustomerThenResponseVerified() throws Exception {
        // Arrange
        createCustomerReservation(EMAIL, TOKEN);
        final String getCustomerPath = ROOT_PATH + "/" + EMAIL + "/customer/";
        // Act
        ResponseEntity<CustomerDtoImpl> response = template.exchange(getCustomerPath, HttpMethod.GET,
                getHttpEntity(null), CustomerDtoImpl.class);
        // Assert
        CustomerDto customer = response.getBody();
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertEquals(EMAIL, customer.getEmail());
        assertNotNull(customer.getId());
        assertEquals(TOKEN, customer.getReservations().iterator().next().getToken());
    }

    @Test
    public void givenValidReservationWhenGetReservationThenResponseVerified() throws Exception {
        // Arrange
        createCustomerReservation(EMAIL, TOKEN);
        final String getReservationPath = ROOT_PATH + "/" + TOKEN + "/reservation/";
        // Act
        ResponseEntity<ReservationDtoImpl> response = template.exchange(getReservationPath, HttpMethod.GET,
                getHttpEntity(null), ReservationDtoImpl.class);
        // Assert
        ReservationDto customer = response.getBody();
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertNotNull(customer.getId());
        assertEquals(TOKEN, customer.getToken());
    }

    @Test
    public void givenValidReservationWhenGetAvailableDatesforPeriodThenResponseVerified() throws Exception {
        // Arrange
        createCustomerReservation();
        final String getReservationPath = ROOT_PATH + "/availability/?fromDate=" + START_DATE +
                "&toDate=" + formatDateTime(NEW_RAW_END_DATE);
        // Act
        ResponseEntity<List<String>> response = template.exchange(getReservationPath, HttpMethod.GET,
                getHttpEntity(null), new ParameterizedTypeReference<List<String>>() {});
        // Assert
        assertEquals(HTTP_STATUS_OK, response.getStatusCode().value());
        assertEquals(3, response.getBody().size());
    }

    //****************************************************
    // Concurrency Tests
    //****************************************************
    @RepeatedTest(10)
    public void givenCustomersWhenCreateConcurrentlyThenResponseVerified() throws Exception {
        // These three customers are trying to book overlapping dates concurrently when create
        // Only one can go ahead, this concurrency can only be detected at MySQL,
        // The response msgs are from executing the create_reservation stored procedure
        // Only One Customer should get the token
        // the others customers should get Helper.SP_MSG_TRY_TO_CREATE_BUT_ALREADY_BOOKED_DAYS
        final int responseLengthforToken = DEFAULT_TOKEN_PATTERN.length() + 4; /* because of ["???#?##?"]*/
        // Arrange
        Callable<ResponseEntity<String>> task1 = () -> createCustomerReservationOne();
        Callable<ResponseEntity<String>> task2 = () -> createCustomerReservationTwo();
        Callable<ResponseEntity<String>> task3 = () -> createCustomerReservationThree();
        // Act and Assert
        executeCallablesAndAssert(Arrays.asList(task1, task2, task3),
                result -> responseLengthforToken == result.length(), SP_MSG_TRY_TO_CREATE_BUT_ALREADY_BOOKED_DAYS);
    }

    @RepeatedTest(10)
    public void givenExistingCustomersWhenUpdateConcurrentlyThenResponseVerified() throws Exception {
        // These three existing customers are trying to book overlapping dates concurrently when update
        // Only one can go ahead, this concurrency can only be detected only detected at MySQL,
        // The response msgs are from executing the update_reservation stored procedure
        // Only One Customer should get the 'success' msg
        // the others customers should get Helper.SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS
        // Arrange
        Callable<ResponseEntity<String>> task1 = () -> updateCustomerReservationOne();
        Callable<ResponseEntity<String>> task2 = () -> updateCustomerReservationTwo();
        Callable<ResponseEntity<String>> task3 = () -> updateCustomerReservationThree();
        // Act and Assert
        executeCallablesAndAssert(Arrays.asList(task1, task2, task3), result -> result.contains(SP_MSG_SUCCESFULL),
                SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS);
    }

    private void executeCallablesAndAssert(final List<Callable<ResponseEntity<String>>> taskList,
            final Predicate<String> result, final String errorMsg) throws Exception {

        final int maxSuccess = 1;
        final int maxFailures = taskList.size() - maxSuccess;
        final AtomicInteger countSuccess = new AtomicInteger(0);
        final AtomicInteger countFailures = new AtomicInteger(0);
        try (Stream<Callable<ResponseEntity<String>>> stream = taskList.parallelStream()) {
            stream
                .map(c -> {
                    try {
                        return c.call();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                })
                .map(r -> r.getBody())
                .forEach(s -> {
//                    System.out.println(Thread.currentThread().getName() + " -->" + s);
                    if (result.test(s)) {
                        countSuccess.incrementAndGet();
                    } else if (s.contains(errorMsg)) {
                        countFailures.incrementAndGet();
                    }
                });
            // Assert
            assertAll(
                () -> assertEquals(maxSuccess, countSuccess.get(), "Success Count"),
                () -> assertEquals(maxFailures, countFailures.get(), "Failures Count")
            );
        }
    }

    private void createCustomerReservation(final String email, final String token) {
        Customer customer = new Customer(email, FIRST_NAME, LAST_NAME);
        customer = customerRepository.save(customer);
        Reservation reservation = new Reservation(token, customer, RAW_START_DATE, RAW_END_DATE);
        reservation = reservationRepository.save(reservation);
        customer.addReservation(reservation);
        reservation.setCustomer(null);
    }

    private void createCustomerReservation() {
        Customer customer = new Customer(EMAIL, FIRST_NAME, LAST_NAME);
        customer = customerRepository.save(customer);

        Reservation reservation = new Reservation(TOKEN, customer, RAW_START_DATE, RAW_END_DATE);
        reservation = reservationRepository.save(reservation);
        customer.addReservation(reservation);
        reservation = new Reservation(NEW_TOKEN, customer, NEW_RAW_START_DATE, NEW_RAW_END_DATE);
        reservation = reservationRepository.save(reservation);
        customer.addReservation(reservation);
        reservation.setCustomer(null);
    }

    private static HttpEntity<Object> getHttpEntity(final Object body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new HttpEntity<Object>(body, headers);
    }

    private ResponseEntity<String> createCustomerReservationOne() throws Exception {
        return createCustomerReservation(START_DATE, END_DATE, NEW_EMAIL, NEW_FIRST_NAME, NEW_LAST_NAME);
    }

    private ResponseEntity<String> createCustomerReservationTwo() {
        return createCustomerReservation(START_DATE, END_DATE, EMAIL, FIRST_NAME, LAST_NAME);
    }

    private ResponseEntity<String> createCustomerReservationThree() {
        return createCustomerReservation(THIRD_START_DATE, THIRD_END_DATE, "Three" + NEW_EMAIL,
                "nfn" + NEW_FIRST_NAME, "nln" + NEW_LAST_NAME);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private ResponseEntity<String> createCustomerReservation(final String startDate, final String endDate,
            final String email, final String firstName, final String lastName) {
        try {
            final ReservationDto reservationDto = new ReservationDtoImpl(null, null, startDate, endDate);
            final CustomerDto customerDto = new CustomerDtoImpl(email, firstName, lastName);
            customerDto.setReservations(new HashSet(Arrays.asList(reservationDto)));
            HttpEntity<Object> createBody = getHttpEntity(objectMapper.writeValueAsString(customerDto));
            return template.exchange(PUT_CREATE, HttpMethod.PUT, createBody, String.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ResponseEntity<String> updateCustomerReservationOne() throws Exception {
        return createCustomerReservationSettingNewValuesAndUpdate(EMAIL,
                TOKEN, RAW_START_DATE, RAW_END_DATE, RAW_FOURTH_START_DATE,
                RAW_FOURTH_END_DATE);
    }

    private ResponseEntity<String> updateCustomerReservationTwo() throws Exception {
        return createCustomerReservationSettingNewValuesAndUpdate(NEW_EMAIL,
                NEW_TOKEN, NEW_RAW_START_DATE, NEW_RAW_END_DATE, RAW_FOURTH_START_DATE,
                RAW_FOURTH_END_DATE);
    }

    private ResponseEntity<String> updateCustomerReservationThree() throws Exception {
        return createCustomerReservationSettingNewValuesAndUpdate(ANOTHER_NEW_EMAIL,
                ANOTHER_NEW_TOKEN, RAW_FITH_START_DATE, RAW_FITH_END_DATE, RAW_FOURTH_START_DATE,
                RAW_FOURTH_END_DATE);
    }

    private ResponseEntity<String> createCustomerReservationSettingNewValuesAndUpdate(final String email,
            final String token, final LocalDate startDate, final LocalDate endDate, final LocalDate overlappingStartDate,
            final LocalDate overlappingEndDate) {
        try {
            // Arrange
            Customer customer = new Customer(email, FIRST_NAME, LAST_NAME);
            customer = customerRepository.save(customer);
            Reservation reservation = new Reservation(token, customer, startDate, endDate);
            reservation = reservationRepository.save(reservation);
            customer.addReservation(reservation);
            reservation.setCustomer(null);

            // Setting OverlappingDate Values
            reservation.setFromDate(overlappingStartDate);
            reservation.setToDate(overlappingEndDate);
            HttpEntity<Object> updateBody = getHttpEntity(objectMapper.writeValueAsString(customer));
            // Act
            return template.exchange(POST_UPDATE + "?oemail=" + email, HttpMethod.POST,
                    updateBody, String.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void deleteAll() {
        reservationRepository.deleteAll();
        customerRepository.deleteAll();
    }
}
