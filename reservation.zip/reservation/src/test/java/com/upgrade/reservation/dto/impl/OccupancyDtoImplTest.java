package com.upgrade.reservation.dto.impl;

import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;
import org.junit.jupiter.api.Test;
import pl.pojo.tester.api.assertion.Method;

class OccupancyDtoImplTest {

    @Test
    public void shouldPassEqualsAndHashCode() throws Exception {
        // Arrange
        final Class<?> classUnderTest = OccupancyDtoImpl.class;

        // Act & Assert
        assertPojoMethodsFor(classUnderTest)
                .testing(Method.EQUALS)
                .testing(Method.HASH_CODE)
                .areWellImplemented();
    }

}
