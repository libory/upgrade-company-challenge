package com.upgrade.reservation.dto;

import org.springframework.http.HttpStatus;

public interface ApiErrorDto {

    HttpStatus getStatus();

    void setStatus(HttpStatus status);

    String getMessage();

    void setMessage(String message);

    String getDebugMessage();

    void setDebugMessage(String debugMessage);

}
