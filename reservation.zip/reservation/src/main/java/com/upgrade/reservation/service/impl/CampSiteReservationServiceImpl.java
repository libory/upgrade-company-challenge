package com.upgrade.reservation.service.impl;

import static com.upgrade.reservation.service.impl.CampSiteReservationServiceUtil.findFreeDate;
import static com.upgrade.reservation.service.impl.CampSiteReservationServiceUtil.validateMaxDaysToBook;
import static com.upgrade.reservation.service.impl.CampSiteReservationServiceUtil.validateMinAndMaxDaysAheadReservation;
import static com.upgrade.reservation.util.Helper.MISSING_CUSTOMER_ID;
import static com.upgrade.reservation.util.Helper.SP_MSG_SUCCESFULL;
import static com.upgrade.reservation.util.Helper.START_DATE_AFTER_END_DATE_ERROR_MSG;
import static com.upgrade.reservation.util.Helper.formatDateTime;
import static com.upgrade.reservation.util.Helper.parseDateTime;
import static java.util.stream.Collectors.toList;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import com.upgrade.reservation.dto.CustomerDto;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.CustomerDtoImpl;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;
import com.upgrade.reservation.exception.ReservationException;
import com.upgrade.reservation.model.Customer;
import com.upgrade.reservation.model.Reservation;
import com.upgrade.reservation.repository.CustomerRepository;
import com.upgrade.reservation.repository.ReservationRepository;
import com.upgrade.reservation.service.CampSiteReservationService;
import com.upgrade.reservation.util.Holder;
import com.upgrade.reservation.util.TokenGenerator;

@Service
@Validated
public class CampSiteReservationServiceImpl implements CampSiteReservationService {

    private final CustomerRepository customerRepository;

    private final ReservationRepository reservationRepository;

    private final TokenGenerator tokenGenerator;

    private final ModelMapper modelMapper;

    @Autowired
    public CampSiteReservationServiceImpl(CustomerRepository customerRepository,
            ReservationRepository reservationRepository, TokenGenerator tokenGenerator, ModelMapper modelMapper) {
        this.customerRepository = customerRepository;
        this.reservationRepository = reservationRepository;
        this.tokenGenerator = tokenGenerator;
        this.modelMapper = modelMapper;
    }

    @Transactional(readOnly = true)
    @Override
    public List<String> getDatesAvailability(final String rawFromDate, final String rawToDate) {
        final LocalDate fromDate;
        final LocalDate toDate;
        if (Objects.isNull(rawFromDate) || Objects.isNull(rawToDate)) {
            fromDate = LocalDate.now();
            toDate = fromDate.plusMonths(1);
        } else {
            fromDate = parseDateTime(rawFromDate);
            toDate = parseDateTime(rawToDate);
        }

        if (fromDate.isAfter(toDate)) {
            throw new ReservationException(START_DATE_AFTER_END_DATE_ERROR_MSG);
        }

        final long days = fromDate.until(toDate, ChronoUnit.DAYS);
        List<OccupancyDto> occupanciesRead =
                reservationRepository.findByDateRange(formatDateTime(fromDate), formatDateTime(toDate));
        final List<OccupancyDto> occupancies = Objects.nonNull(occupanciesRead) ? occupanciesRead : Collections.emptyList();

        try (IntStream daysStream = IntStream.iterate(0, i -> ++i).limit(days + 1)) {
            // Note: Using the common Thread Pool for this POC.
            // Note: List<String> returned contains Dates in ISO Format
            final List<String> availableDates = daysStream
                    .parallel()
                    .mapToObj(j -> findFreeDate(j, occupancies, fromDate))
                    .filter(stringDateOpt -> stringDateOpt.isPresent())
                    .map(stringDateOpt -> stringDateOpt.get())
                    .collect(toList());
            return CollectionUtils.isEmpty(availableDates) ? Collections.emptyList() : availableDates;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public CustomerDto get(@Email final String email) {
        return customerRepository.findByEmail(email)
                .map(c -> {
                    if (!CollectionUtils.isEmpty(c.getReservations())) {
                        c.getReservations().forEach(r -> r.setCustomer(null));
                    }
                    return modelMapper.map(c, CustomerDtoImpl.class);
                 })
                .orElseThrow(() -> new ReservationException("No Customer found for " + email));
    }

    @Override
    @Transactional(readOnly = true)
    public ReservationDto getReservation(@NotNull final String token) {
        return reservationRepository.findByToken(token)
                .map(r -> {
                    r.getCustomer().setReservations(null);
                    return modelMapper.map(r, ReservationDtoImpl.class);
                 })
                .orElseThrow(() -> new ReservationException("No Reservation found for " + token));
    }

    @Override
    @Transactional
    public void cancel(@NotNull final Holder<List<ReservationDtoImpl>> reservationDtoListHolder) {
        // TODO: Note: Spring Batch for this? (Normally people would have 1 or 2 reservations but...?)
        if (CollectionUtils.isEmpty(reservationDtoListHolder.getValue())) {
            throw new ReservationException("Reservation(s) to Delete is(are) missing.");
        }
        try (Stream<ReservationDtoImpl> reservationStream = reservationDtoListHolder.getValue().stream()) {
            reservationStream
                .map(dto -> isValidReservation(dto.getToken(), dto.getId()))
                .forEach(reservationRepository::delete);
        }
    }

    @Override
    @Transactional
    public List<String> create(@Valid final CustomerDto customerDto) {
        Runnable extraValidations = () ->  Objects.requireNonNull(customerDto, "Customer Information is missing.");
        return createOrUpdate(customerDto, true, extraValidations, null);
    }

    @Override
    @Transactional
    public List<String> modify(@Valid final CustomerDto customerDto, @Email String oldEmail) {
        // Note: For this POC --> Strategy: sending Customer and Reservations data to be updated
        // thru only 1 connection on MySQL, normal Hibernate strategy is 2 round-trips to
        // DB(1 for Cust and 1 for Reservation)
        // Drawback of my Strategy: Everything gets updated again even if not modified(Hibernate
        // normally does determine if a persisted ENtity needs to be updated).
        // TODO: Detect if there are changes in Customer and reservations
        // and only save what has changed.(using the equals(..) method)
        Runnable extraValidations = () ->  {
            if (Objects.isNull(customerDto) || Objects.isNull(customerDto.getId())) {
                throw new ReservationException("Customer Information is missing.");
            }
        };
        return createOrUpdate(customerDto, false, extraValidations, oldEmail);
    }

    private List<String> createOrUpdate(final CustomerDto customerDto, final boolean callFromCreate,
            final Runnable extraValidations, String oldEmail) {
        if (Objects.nonNull(extraValidations)) {
            extraValidations.run();
        }

        Set<ReservationDtoImpl> reservation = customerDto.getReservations();
        if (CollectionUtils.isEmpty(reservation)) {
            throw new ReservationException("This Customer does not contain Reservation Info.");
        }
        try (Stream<ReservationDtoImpl> reservationStream =  reservation.parallelStream()) {
            final CustomerDto unmodifCustomerDto = customerDto.unmodifiableCustomerDto();

            final String emailToSearch = callFromCreate ? unmodifCustomerDto.getEmail() : oldEmail;
            final Optional<Customer> customerOpt = customerRepository.findByEmail(emailToSearch);
            final boolean existCustomer = customerOpt.isPresent();
            final Long customerId = (existCustomer) ? customerOpt.get().getId() : MISSING_CUSTOMER_ID;
            if (existCustomer && !customerId.equals(customerDto.getId())) {
                throw new ReservationException("Bad or Missing Customer id.");
            }
            return callFromCreate
                    ?
                        reservationStream
                            .map(dto -> createReservation(dto, unmodifCustomerDto, customerId))
                            .collect(toList())
                    :
                        reservationStream
                            .map(dto -> updateReservation(dto, unmodifCustomerDto, customerId))
                            .collect(toList());
        }
    }

    private String createReservation(final ReservationDto reservationDto, final CustomerDto customerDto,
            final long customerId) {
        Runnable extraValidations = () -> {
            Objects.requireNonNull(reservationDto, "Reservation Information can not be empty or null.");
            validateStartDateBeforeEndDatesForReservation(reservationDto.getFromDate(), reservationDto.getToDate());
        };
        return createOrUpdateReservation(reservationDto, customerDto, customerId, extraValidations, true);
    }

    private String updateReservation(final ReservationDto reservationDto, final CustomerDto customerDto,
            final long customerId) {
        Runnable extraValidations = () -> {
            if (Objects.isNull(reservationDto) || Objects.isNull(reservationDto.getId())) {
                throw new ReservationException("Reservation Information is missing.");
            }
            validateStartDateBeforeEndDatesForReservation(reservationDto.getFromDate(), reservationDto.getToDate());
            isValidReservation(reservationDto.getToken(), reservationDto.getId());
        };
        return createOrUpdateReservation(reservationDto, customerDto, customerId, extraValidations, false);
    }

    private String createOrUpdateReservation(final ReservationDto reservationDto, final CustomerDto customerDto,
            final long customerId, Runnable extraValidations, final boolean callFromCreate) {

        if (Objects.nonNull(extraValidations)) {
            extraValidations.run();
        }
        validateMaxDaysToBook(reservationDto);
        validateMinAndMaxDaysAheadReservation(reservationDto);

        int existsOccupancy =
                reservationRepository.existsOccupancyByDateRange(reservationDto.getFromDate(),
                        reservationDto.getToDate(), callFromCreate ? MISSING_CUSTOMER_ID : reservationDto.getId());
        if (existsOccupancy > 0) {
            throw new ReservationException("Some/all days from the intended Reservation's dates are "
                    + "already booked by you or other Customer. Please try again.");
        }

        String result;
        final String email = customerDto.getEmail();
        final String firstName = customerDto.getFirstName();
        final String lastName = customerDto.getLastName();
        // TODO
        // Note: Create ResultDTO class with token and result and return it from here,
        // (it would be a more detailed response to UI)
        if (callFromCreate) {
            String token = tokenGenerator.bothify();
            result = reservationRepository.create(customerId, email, firstName, lastName,
                         reservationDto.getFromDate(), reservationDto.getToDate(), token);
            result = (SP_MSG_SUCCESFULL.equalsIgnoreCase(result)) ? token : result;
        } else {
            result = reservationRepository.update(customerId, reservationDto.getId(), email, firstName, lastName,
                         reservationDto.getFromDate(), reservationDto.getToDate());
        }

        return result;
    }

    private Reservation isValidReservation(final String token, final Long reservationId) {
        // Note: Extra Validation
        if (Objects.isNull(token) || Objects.isNull(reservationId)) {
            throw new ReservationException("Bad token or Reservation Id");
        }
        Optional<Reservation> reservationOpt = reservationRepository.findById(reservationId);
        Reservation reservation;
        if (!reservationOpt.isPresent() || !(reservation = reservationOpt.get()).getToken().equals(token)) {
            throw new ReservationException("Missing Reservation info or Bad token.");
        }
        return reservation;
    }

    private static void validateStartDateBeforeEndDatesForReservation(String rawFromDate, String rawToDate) {
        LocalDate fromDate = parseDateTime(rawFromDate);
        LocalDate toDate = parseDateTime(rawToDate);
        if (fromDate.isAfter(toDate) || fromDate.equals(toDate)) {
            throw new ReservationException(START_DATE_AFTER_END_DATE_ERROR_MSG);
        }
    }

}
