package com.upgrade.reservation.repository;

public interface JpaRepoMarker {

}
