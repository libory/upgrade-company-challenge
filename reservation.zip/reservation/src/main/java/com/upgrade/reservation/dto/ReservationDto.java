package com.upgrade.reservation.dto;

import com.upgrade.reservation.dto.impl.CustomerDtoImpl;

public interface ReservationDto {

    String getFromDate();

    void setFromDate(String fromDate);

    String getToDate();

    void setToDate(String toDate);

    String getToken();

    void setToken(String token);

    Long getId();

    void setId(Long anId);

    CustomerDto getCustomer();

    void setCustomer(CustomerDtoImpl customer);

}
