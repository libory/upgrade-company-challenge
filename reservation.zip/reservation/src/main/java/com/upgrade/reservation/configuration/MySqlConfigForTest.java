package com.upgrade.reservation.configuration;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.mysql.cj.jdbc.MysqlConnectionPoolDataSource;
import com.upgrade.reservation.model.JpaEntityMarker;
import com.upgrade.reservation.repository.JpaRepoMarker;

@Configuration
@EnableTransactionManagement
@PropertySource("classpath:application-test.properties")
@EnableJpaRepositories(basePackageClasses = JpaRepoMarker.class)
@Profile("test")
public class MySqlConfigForTest {

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String userName;

    @Value("${spring.datasource.password}")
    private String password;

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public DataSource dataSource() {
        MysqlConnectionPoolDataSource mySqlDataSource = new MysqlConnectionPoolDataSource();
        mySqlDataSource.setURL(url);
        mySqlDataSource.setUser(userName);
        mySqlDataSource.setPassword(password);
        return mySqlDataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabase(Database.MYSQL);
        vendorAdapter.setGenerateDdl(true);

        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setJpaVendorAdapter(vendorAdapter);
        factory.setPackagesToScan(JpaEntityMarker.class.getPackage().getName());
        factory.setDataSource(dataSource());
        Map<String, String> prop = new HashMap<>();
//        prop.put("hibernate.jdbc.batch_size", "50");
        prop.put("hibernate.generate_statistics", "true");
        return factory;
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager txManager = new JpaTransactionManager();
        txManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return txManager;
    }

}
