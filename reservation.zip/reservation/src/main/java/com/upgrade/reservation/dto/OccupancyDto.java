package com.upgrade.reservation.dto;

import java.time.LocalDate;

public interface OccupancyDto {

    LocalDate getFromDate();

    LocalDate getToDate();

}
