package com.upgrade.reservation.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

@Entity
@NamedStoredProcedureQuery(name = "Reservation.exists_reservation", procedureName = "exists_reservation",
    parameters = {
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "from_date", type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "to_date", type = String.class),
        @StoredProcedureParameter(mode = ParameterMode.IN, name = "reserv_id", type = long.class),
        @StoredProcedureParameter(mode = ParameterMode.OUT, name = "ocupancies_count", type = int.class)
    })

@NamedStoredProcedureQuery(name = "Reservation.create_reservation", procedureName = "create_reservation",
parameters = {
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "cust_id", type = long.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "email", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "first_name", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "last_name", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "from_date", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "to_date", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "token", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "result", type = int.class)
})
@NamedStoredProcedureQuery(name = "Reservation.update_reservation", procedureName = "update_reservation",
parameters = {
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "cust_id", type = long.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "reserv_id", type = long.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "email", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "first_name", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "last_name", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "from_date", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.IN, name = "to_date", type = String.class),
    @StoredProcedureParameter(mode = ParameterMode.OUT, name = "result", type = int.class)
})
public class Reservation implements Serializable {

    private static final long serialVersionUID = 5664270642278211625L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false, length = 19)
    private Long id;

    @Column(nullable = false)
    private String token;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(name = "from_date", nullable = false)
    private LocalDate fromDate;

    @Column(name = "to_date", nullable = false)
    private LocalDate toDate;

    public Reservation() {
    }

    public Reservation(String token, Customer customer, LocalDate fromDate, LocalDate toDate) {
        this.token = token;
        this.customer = customer;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long anId) {
        id = anId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Reservation other = (Reservation) obj;
        return Objects.equals(id, other.id)
                && Objects.equals(customer, other.customer)
                && Objects.equals(fromDate, other.fromDate)
                && Objects.equals(toDate, other.toDate)
                && Objects.equals(token, other.token);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, customer, fromDate, toDate, token);
    }

    @Override
    public String toString() {
        return "Reservation{id=" + id + ", "
                + "customer=" + customer + ", "
                + "fromDate=" + fromDate + ", "
                + "toDate=" + toDate + ", "
                + "token=" + token
                + "}";
    }
}
