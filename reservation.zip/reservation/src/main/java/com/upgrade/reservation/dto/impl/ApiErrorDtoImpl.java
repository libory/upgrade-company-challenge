package com.upgrade.reservation.dto.impl;

import java.io.Serializable;
import java.util.Objects;
import org.springframework.http.HttpStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.upgrade.reservation.dto.ApiErrorDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiErrorDtoImpl implements ApiErrorDto, Serializable {

    private static final long serialVersionUID = 4669388574085650999L;

    private HttpStatus status;
    private String message;
    private String debugMessage;

    @Override
    public HttpStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String getDebugMessage() {
        return debugMessage;
    }

    @Override
    public void setDebugMessage(String debugMessage) {
        this.debugMessage = debugMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApiErrorDtoImpl apiError = (ApiErrorDtoImpl) o;
        return Objects.equals(status, apiError.status) &&
                Objects.equals(message, apiError.message) &&
                Objects.equals(debugMessage, apiError.debugMessage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, message, debugMessage);
    }

    @Override
    public String toString() {
        return "ApiError{" +
                "status=" + status +
                ", message='" + message + '\'' +
                ", debugMessage='" + debugMessage + '\'' +
                '}';
    }
}
