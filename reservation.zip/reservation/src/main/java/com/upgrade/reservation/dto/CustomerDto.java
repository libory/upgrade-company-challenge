package com.upgrade.reservation.dto;

import java.util.Set;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;

public interface CustomerDto {

    String getEmail();

    void setEmail(String email);

    String getFirstName();

    void setFirstName(String firstName);

    String getLastName();

    void setLastName(String lastName);

    Long getId();

    void setId(Long id);

    Set<ReservationDtoImpl> getReservations();

    void setReservations(Set<ReservationDtoImpl> reservations);

    CustomerDto unmodifiableCustomerDto();

}
