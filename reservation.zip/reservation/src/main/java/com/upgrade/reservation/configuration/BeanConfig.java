package com.upgrade.reservation.configuration;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.upgrade.reservation.util.Helper;
import com.upgrade.reservation.util.TokenGenerator;

@Configuration
public class BeanConfig {

    @Bean
    public TokenGenerator getTokenGenerator() {
        return new TokenGenerator(Helper.DEFAULT_TOKEN_PATTERN);
    }

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        return modelMapper;
    }

}
