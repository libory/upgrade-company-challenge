package com.upgrade.reservation.dto.impl;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.upgrade.reservation.dto.OccupancyDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OccupancyDtoImpl implements OccupancyDto, Serializable {

    private static final long serialVersionUID = 4826082415506813622L;

    private LocalDate fromDate;
    private LocalDate toDate;

    public OccupancyDtoImpl() {
    }

    public OccupancyDtoImpl(LocalDate fromDate, LocalDate toDate) {
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    @Override
    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    @Override
    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        OccupancyDtoImpl other = (OccupancyDtoImpl) obj;
        return Objects.equals(fromDate, other.fromDate)
                && Objects.equals(toDate, other.toDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fromDate, toDate);
    }

    @Override
    public String toString() {
        return "OccupancyDto{"
                + "fromDate=" + fromDate + ", "
                + "toDate=" + toDate + ", "
                + "}";
    }
}
