package com.upgrade.reservation.dto.impl;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.upgrade.reservation.dto.CustomerDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDtoImpl implements CustomerDto, Serializable {

    private static final long serialVersionUID = -2094210567145346212L;

    private Long id;

    @Email(message = "A valid email should be provided.")
    private String email;

    @NotBlank(message = "First Name can not be empty.")
    @Size(min = 1, max = 255, message = "First Name's length should be less than 255 character.")
    private String firstName;

    @NotBlank(message = "Last Name can not be empty.")
    @Size(min = 1, max = 255, message = "Last Name's length should be less than 255 character.")
    private String lastName;

    private Set<ReservationDtoImpl> reservations = new HashSet<>();

    public CustomerDtoImpl() {
    }

    public CustomerDtoImpl(String email, String firstName, String lastName) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Set<ReservationDtoImpl> getReservations() {
        return reservations;
    }

    @Override
    public void setReservations(Set<ReservationDtoImpl> reservations) {
        this.reservations = reservations;
    }

    @Override
    public CustomerDto unmodifiableCustomerDto() {
        return new UnModifiableCustomerDto(id, email, firstName, lastName);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        CustomerDtoImpl other = (CustomerDtoImpl) obj;
        return Objects.equals(id, other.id)
               && Objects.equals(email, other.email)
               && Objects.equals(firstName, other.firstName)
               && Objects.equals(lastName, other.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email, firstName, lastName);
    }

    @Override
    public String toString() {
        return "CustomerDtoImpl{"
                + "id=" + id + ", "
                + "email=" + email + ", "
                + "firstName=" + firstName + ", "
                + "lastName=" + lastName + ", "
                + " reservations=" + reservations
                + "}";
    }

    private static class UnModifiableCustomerDto implements CustomerDto, Serializable {

        private static final long serialVersionUID = 4476198143603973663L;

        private Long id;

        private String email;

        private String firstName;

        private String lastName;

        private UnModifiableCustomerDto(Long id, String email, String firstName, String lastName) {
            this.id = id;
            this.email = email;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        @Override
        public String getEmail() {
            return email;
        }

        @Override
        public void setEmail(String email) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getFirstName() {
            return firstName;
        }

        @Override
        public void setFirstName(String firstName) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getLastName() {
            return lastName;
        }

        @Override
        public void setLastName(String lastName) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Long getId() {
            return id;
        }

        @Override
        public void setId(Long id) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Set<ReservationDtoImpl> getReservations() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setReservations(Set<ReservationDtoImpl> reservations) {
            throw new UnsupportedOperationException();
        }

        @Override
        public CustomerDto unmodifiableCustomerDto() {
            throw new UnsupportedOperationException();
        }

        @Override
        public String toString() {
            return "UnModifiableCustomerDto{"
                    + "id=" + id + ", "
                    + "email=" + email + ", "
                    + "firstName=" + firstName + ", "
                    + "lastName=" + lastName + ", "
                    + "}";
        }

    }
}
