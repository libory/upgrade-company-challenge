package com.upgrade.reservation.service.impl;

import static com.upgrade.reservation.util.Helper.CHECKIN_TIME;
import static com.upgrade.reservation.util.Helper.MAX_DAYS_TO_BOOK;
import static com.upgrade.reservation.util.Helper.MAX_DAYS_TO_BOOK_ERROR_MSG;
import static com.upgrade.reservation.util.Helper.MAX_MONTHS_AHEAD_ARRIVAL_IN_MINUTES;
import static com.upgrade.reservation.util.Helper.MIN_DAYS_AHEAD_ARRIVAL_IN_MINUTES;
import static com.upgrade.reservation.util.Helper.MIN_MAX_DAYS_AHEAD_TO_BOOK_ERROR_MSG;
import static com.upgrade.reservation.util.Helper.formatDateTime;
import static com.upgrade.reservation.util.Helper.parseDateTime;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.exception.ReservationException;

public final class CampSiteReservationServiceUtil {

    private CampSiteReservationServiceUtil() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    static Optional<String> findFreeDate(final int index, final List<OccupancyDto> occupancies,
            final LocalDate fromDate) {
        Objects.requireNonNull(fromDate);
        Objects.requireNonNull(occupancies);

        LocalDate nextDate = fromDate.plusDays(index);
        boolean found = false;
        for (int k = 0; k < occupancies.size(); ++k) {
            OccupancyDto occupancyDto = occupancies.get(k);
            if (occupancyDto.getFromDate().isBefore(nextDate)
                    && occupancyDto.getToDate().isAfter(nextDate)
                    || occupancyDto.getFromDate().equals(nextDate)) {
                found = true;
                break;
            } else if (occupancyDto.getFromDate().isAfter(nextDate)
                    || occupancyDto.getToDate().equals(nextDate)
                    && k <= occupancies.size() - 2
                    && !occupancies.get(k + 1).getFromDate().equals(nextDate)) {
                break;
            }
        }
        return Optional.ofNullable((found) ? null : formatDateTime(nextDate));
    }

    static void validateMaxDaysToBook(final ReservationDto reservationDto) {
        Objects.requireNonNull(reservationDto);

        final LocalDate fromDate = parseDateTime(reservationDto.getFromDate());
        final LocalDate toDate = parseDateTime(reservationDto.getToDate());
        long expectedDays;
        try {
            expectedDays = fromDate.until(toDate, ChronoUnit.DAYS);
        } catch (RuntimeException e) {
            // Note: A possible long overflow
            throw new ReservationException(MAX_DAYS_TO_BOOK_ERROR_MSG, e);
        }
        if (expectedDays > MAX_DAYS_TO_BOOK) {
            throw new ReservationException(MAX_DAYS_TO_BOOK_ERROR_MSG);
        }
    }

    static void validateMinAndMaxDaysAheadReservation(final ReservationDto reservationDto) {
        Objects.requireNonNull(reservationDto);

        final LocalDate fromDate = parseDateTime(reservationDto.getFromDate());
        final LocalDateTime fromDateTime = LocalDateTime.of(fromDate.getYear(), fromDate.getMonthValue(),
                fromDate.getDayOfMonth(), CHECKIN_TIME.getHour(), CHECKIN_TIME.getMinute(), CHECKIN_TIME.getSecond());
        final LocalDateTime now = LocalDateTime.now();
        final long aheadArrivalDaysInMinutes;
        try {
            aheadArrivalDaysInMinutes = now.until(fromDateTime, ChronoUnit.MINUTES);
        } catch (RuntimeException e) {
            // Note: A possible long overflow
            throw new ReservationException(MIN_MAX_DAYS_AHEAD_TO_BOOK_ERROR_MSG, e);
        }
        if (aheadArrivalDaysInMinutes < MIN_DAYS_AHEAD_ARRIVAL_IN_MINUTES
                || MAX_MONTHS_AHEAD_ARRIVAL_IN_MINUTES < aheadArrivalDaysInMinutes) {
            throw new ReservationException(MIN_MAX_DAYS_AHEAD_TO_BOOK_ERROR_MSG);
        }
    }
}
