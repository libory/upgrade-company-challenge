package com.upgrade.reservation.util;

import java.util.Objects;
import java.util.Random;
import org.apache.commons.lang3.StringUtils;

// More References in Faker.java class(original implementation)
public class TokenGenerator {

    private static final String INVALID_PARAMETER_MSG = "Invalid Parameter";
    private static final char TEXT_PLACEHOLDER = '?';
    private static final char NUMBER_PLACEHOLDER = '#';
    private static final char LOWER_BOUNDED_NUMBER = '0';
    private static final char UPPER_BOUNDED_NUMBER = '9';

    private final Random generator = new Random();
    private char lowerBoundedLetter = 'a';
    private char upperBoundedLetter = 'z';
    private String defaultPattern = "?#";

    public TokenGenerator() {
    }

    public TokenGenerator(String defaultPattern, char lowerBoundedLetter, char upperBoundedLetter) {
        this(defaultPattern);
        this.lowerBoundedLetter = lowerBoundedLetter;
        this.upperBoundedLetter = upperBoundedLetter;
    }

    public TokenGenerator(String defaultPattern) {
        if (StringUtils.isBlank(defaultPattern)) {
            throw new IllegalArgumentException("Bad DefaultPattern value for TokenGenerator.");
        }
        this.defaultPattern  = defaultPattern ;
    }

    public String bothify() {
        return bothify(defaultPattern);
    }

    public String bothify(final String pattern) {
        if (Objects.isNull(pattern) || pattern.indexOf(NUMBER_PLACEHOLDER) < 0
                && pattern.indexOf(TEXT_PLACEHOLDER) < 0) {
            return pattern;
        }
        final char[][] parameters = {
            {TEXT_PLACEHOLDER, upperBoundedLetter, lowerBoundedLetter},
            {NUMBER_PLACEHOLDER, UPPER_BOUNDED_NUMBER, LOWER_BOUNDED_NUMBER}
        };
        return renderify(pattern, parameters);
    }

    private int calculateSeed(final char lowerBoundedLetter, final char upperBoundedLetter) {
        if (lowerBoundedLetter > upperBoundedLetter) {
            throw new IllegalArgumentException("UpperBoundedCharacter value must be bigger "
                    + "than LowerBoundedCharacter value.");
        }
        return upperBoundedLetter - lowerBoundedLetter + 1;
    }

    private String renderify(final String text, final char[][] parameters) {
        Objects.requireNonNull(text, INVALID_PARAMETER_MSG);
        Objects.requireNonNull(parameters, INVALID_PARAMETER_MSG);

        final StringBuilder newText = new StringBuilder(text.length()).append(text);
        for(char[] parameter : parameters) {
            final int seed = calculateSeed(parameter[2], parameter[1]);
            int index;
            final String letterPlaceHolder = String.valueOf(parameter[0]);
            while((index = newText.indexOf(letterPlaceHolder)) >= 0) {
                newText.replace(index, index + 1, Character.toString((char)(parameter[2] + generator.nextInt(seed))));
            }
        }
        return newText.toString();
    }

}
