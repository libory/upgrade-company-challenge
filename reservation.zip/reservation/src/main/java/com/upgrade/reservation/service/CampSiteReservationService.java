package com.upgrade.reservation.service;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import com.upgrade.reservation.dto.CustomerDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;
import com.upgrade.reservation.util.Holder;

public interface CampSiteReservationService {

    List<String> getDatesAvailability(String rawFromDate, String rawToDate);

    List<String> create(@Valid CustomerDto reservationDto);

    List<String> modify(@Valid CustomerDto customerDto, @Email String oldEmail);

    void cancel(@NotNull Holder<List<ReservationDtoImpl>> customerDto);

    CustomerDto get(@Email String email);

    ReservationDto getReservation(@NotNull String token);

}
