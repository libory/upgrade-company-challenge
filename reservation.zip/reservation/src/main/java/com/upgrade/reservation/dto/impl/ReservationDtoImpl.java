package com.upgrade.reservation.dto.impl;

import java.io.Serializable;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.upgrade.reservation.dto.ReservationDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReservationDtoImpl implements ReservationDto, Serializable {

    private static final long serialVersionUID = 7480985078149847207L;

    private Long id;

    private String token;

    @NotBlank(message = "Start Date can not be empty.")
    @Pattern(regexp = "^yyyy-MM-dd$", message = "Start Date should be in 'yyyy-MM-dd' format")
    private String fromDate;

    @NotBlank(message = "End Date can not be empty.")
    @Pattern(regexp = "^yyyy-MM-dd$", message = "End Date should be in 'yyyy-MM-dd' format")
    private String toDate;

    private CustomerDtoImpl customer;

    public ReservationDtoImpl() {
    }

    public ReservationDtoImpl(Long id, String token, String fromDate, String toDate) {
        this.id = id;
        this.token = token;
        this.fromDate = fromDate;
        this.toDate = toDate;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long anId) {
        id = anId;
    }

    @Override
    public String getToken() {
        return token;
    }

    @Override
    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String getFromDate() {
        return fromDate;
    }

    @Override
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    @Override
    public String getToDate() {
        return toDate;
    }

    @Override
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    @Override
    public CustomerDtoImpl getCustomer() {
        return customer;
    }

    @Override
    public void setCustomer(CustomerDtoImpl customer) {
        this.customer = customer;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ReservationDtoImpl other = (ReservationDtoImpl) obj;
        return Objects.equals(id, other.id)
               && Objects.equals(token, other.token)
               && Objects.equals(fromDate, other.fromDate)
               && Objects.equals(toDate, other.toDate)
               && Objects.equals(customer, other.customer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, token, fromDate, toDate, customer);
    }

    @Override
    public String toString() {
        return "ReservationDtoImpl{"
                + "id=" + id + ", "
                + "token=" + token + ", "
                + "fromDate=" + fromDate + ", "
                + "toDate=" + toDate + ", "
                + "customer=" + customer + ", "
                + "}";
    }

}
