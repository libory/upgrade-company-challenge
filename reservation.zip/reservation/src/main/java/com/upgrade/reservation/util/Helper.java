package com.upgrade.reservation.util;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import com.upgrade.reservation.exception.ReservationException;

public final class Helper {

    public static final String DEFAULT_TOKEN_PATTERN = "???#?##?";
    public static final LocalTime CHECKIN_TIME = LocalTime.of(12, 0, 0);
    public static final long MISSING_CUSTOMER_ID = -1L;
    public static final int MAX_DAYS_TO_BOOK = 3;
    public static final long MIN_DAYS_AHEAD_ARRIVAL = 1L;
    public static final long MIN_DAYS_AHEAD_ARRIVAL_IN_MINUTES = TimeUnit.DAYS.toMinutes(MIN_DAYS_AHEAD_ARRIVAL);
    public static final long MAX_MONTHS_AHEAD_ARRIVAL = 30L;
    public static final long MAX_MONTHS_AHEAD_ARRIVAL_IN_MINUTES = TimeUnit.DAYS.toMinutes(MAX_MONTHS_AHEAD_ARRIVAL);
    public static final DateTimeFormatter DATE_TIME_FORMATTER_FROM_INPUT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    // TODO Note: Place these constants in a separate ENUM
    public static final String SP_MSG_SUCCESFULL = "success";
    public static final String SP_MSG_DUPLICATED_KEYS = "Duplicate keys error encountered. "
            + "Email or Token already found in the Database.";
    public static final String SP_MSG_ALREADY_BOOKED = "Some/all days from the intended Reservation dates "
            + "were just booked in Database.";
    public static final String SP_MSG_SQL_ERROR = "SQLException encountered in the Database";
    public static final String SP_MSG_CUSTOMER_BUT_ALREADY_BOOKED_DAYS = "Customer info was update but some/all days from "
            + "the intended Reservation dates were just booked in Database.";
    public static final String SP_MSG_TRY_TO_CREATE_BUT_ALREADY_BOOKED_DAYS =
            "Some/all days from the intended Reservation dates were just booked in Database.";
    public static final String SP_MSG_NON_EXISTING_CUSTOMER = "Customer does not exist.";
    public static final String MAX_DAYS_TO_BOOK_ERROR_MSG =
            "The campsite can be reserved max " + MAX_DAYS_TO_BOOK + " days.";
    public static final String MIN_MAX_DAYS_AHEAD_TO_BOOK_ERROR_MSG = new StringBuilder("The campsite can be reserved minimum ")
            .append(MIN_DAYS_AHEAD_ARRIVAL)
            .append(" day(s) ahead of arrival and up to ")
            .append(MAX_MONTHS_AHEAD_ARRIVAL)
            .append(" day(s) in advance.")
            .toString();
    public static final String START_DATE_AFTER_END_DATE_ERROR_MSG = "Start date should be prior to End Date.";

    private Helper() {
        throw new UnsupportedOperationException("This class cannot be instantiated");
    }

    public static LocalDate parseDateTime(final String rawDate) {
        return  parseDateTime(rawDate, DATE_TIME_FORMATTER_FROM_INPUT);
    }

    public static String formatDateTime(final LocalDate dateTime) {
        return formatDateTime(dateTime, DATE_TIME_FORMATTER_FROM_INPUT);
    }

    public static LocalDate parseDateTime(final String rawDate, final DateTimeFormatter dateTimeFormattert) {
        try {
            Objects.requireNonNull(rawDate);
            return LocalDate.parse(rawDate, dateTimeFormattert);
        } catch (RuntimeException e) {
            throw new ReservationException("This value '" + rawDate + "' has a no valid Date format.", e);
        }
    }

    public static String formatDateTime(final LocalDate date, final DateTimeFormatter dateTimeFormattert) {
        try {
            Objects.requireNonNull(date);
            return date.format(dateTimeFormattert);
        } catch (RuntimeException e) {
            throw new ReservationException("This value '" + date + "' is not a valid LocalDate.", e);
        }
    }

}
