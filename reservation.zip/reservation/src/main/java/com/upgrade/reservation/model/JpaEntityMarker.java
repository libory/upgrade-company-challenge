package com.upgrade.reservation.model;

public interface JpaEntityMarker {

}
