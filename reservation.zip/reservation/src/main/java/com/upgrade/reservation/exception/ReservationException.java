package com.upgrade.reservation.exception;

public class ReservationException extends RuntimeException {

    private static final long serialVersionUID = 8027032410320658794L;

    public ReservationException(String message) {
        super(message);
    }

    public ReservationException(Throwable cause) {
        super(cause);
    }

    public ReservationException(String message, Throwable cause) {
        super(message, cause);
    }
}
