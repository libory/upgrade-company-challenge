package com.upgrade.reservation.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.upgrade.reservation.dto.OccupancyDto;
import com.upgrade.reservation.model.Reservation;

@Repository
public interface ReservationRepository extends CrudRepository<Reservation, Long> {

    @Query(value = " SELECT r.from_date as fromDate, r.to_date as toDate " +
            " FROM reservation r "  +
            " WHERE r.from_date BETWEEN :startDate AND :endDate " +
            " OR r.to_date > :startDate AND r.to_date < :endDate " +
            " ORDER BY fromDate", nativeQuery = true)
    List<OccupancyDto> findByDateRange(@Param("startDate") String startDate,
            @Param("endDate") String endDate);

    @Procedure("exists_reservation")
    int existsOccupancyByDateRange(String startDate, String endDate, long reservationId);

    @Procedure("create_reservation")
    @Transactional
    String create(long customerId, String email, String firstName, String lastName, String startDate,
            String endDate,  String token);

    @Procedure("update_reservation")
    @Transactional
    String update(long customerId, long reservationId, String email, String firstName, String lastName, String startDate,
            String endDate);

    Optional<Reservation> findByToken(String token);

    //     @Modifying
    //     @Transactional
    //     @Query(value = "DELETE FROM reservation WHERE id = :reservationId", nativeQuery = true)
    //     void deleteReservation(@Param("reservationId") long reservationId);
}
