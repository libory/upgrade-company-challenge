package com.upgrade.reservation.controller;

import static com.upgrade.reservation.util.Helper.SP_MSG_SUCCESFULL;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.upgrade.reservation.dto.CustomerDto;
import com.upgrade.reservation.dto.ReservationDto;
import com.upgrade.reservation.dto.impl.CustomerDtoImpl;
import com.upgrade.reservation.dto.impl.ReservationDtoImpl;
import com.upgrade.reservation.service.CampSiteReservationService;
import com.upgrade.reservation.util.Holder;

@RestController
@RequestMapping("/campsite-api")
public class CampSiteReservationController {

  private final CampSiteReservationService campSiteReservationService;

    public CampSiteReservationController(CampSiteReservationService campSiteReservationService) {
        this.campSiteReservationService = campSiteReservationService;
    }

  @GetMapping(path = "/availability/")
  public ResponseEntity<List<String>> getAvailableDatesforPeriod(
      @RequestParam(value = "fromDate", required = false) String fromDate,
      @RequestParam(value = "toDate", required = false) String toDate) {

      return ResponseEntity.ok(campSiteReservationService.getDatesAvailability(fromDate, toDate));
  }

  @GetMapping(path = "/{email}/customer/")
  public ResponseEntity<CustomerDto> getCustomer(@PathVariable(value = "email") String email) {
      return ResponseEntity.ok(campSiteReservationService.get(email));
  }

  @GetMapping(path = "/{token}/reservation/")
  public ResponseEntity<ReservationDto> getReservation(@PathVariable(value = "token") String token) {
      return ResponseEntity.ok(campSiteReservationService.getReservation(token));
  }

  @PutMapping(path = "/reservation/")
  public ResponseEntity<List<String>> create(@RequestBody CustomerDtoImpl customerDto) {
      return ResponseEntity.ok(campSiteReservationService.create(customerDto));
  }

  @PostMapping(path = "/reservation/")
  public ResponseEntity<List<String>> update(@RequestBody CustomerDtoImpl customerDto,
          @RequestParam(value = "oemail") String oldEmail) {
      return ResponseEntity.ok(campSiteReservationService.modify(customerDto, oldEmail));
  }

  @DeleteMapping(path = "/reservation/")
  public ResponseEntity<String> removeReservations(@RequestBody Holder<List<ReservationDtoImpl>> reservationsToCancel) {
      campSiteReservationService.cancel(reservationsToCancel);
      return ResponseEntity.ok(SP_MSG_SUCCESFULL);
  }

}
