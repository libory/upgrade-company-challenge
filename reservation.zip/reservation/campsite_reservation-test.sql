CREATE DATABASE  IF NOT EXISTS `campsite_reservation-test` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `campsite_reservation-test`;
-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: campsite_reservation-test
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `reservation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(45) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_UNIQUE` (`token`),
  KEY `id_idx` (`customer_id`),
  CONSTRAINT `FKmrfygyy9wi4be7nlyuogrn24n` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `customer_fk` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'campsite_reservation-test'
--

--
-- Dumping routines for database 'campsite_reservation-test'
--
/*!50003 DROP PROCEDURE IF EXISTS `create_reservation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_reservation`(
IN cust_id bigint,
IN email varchar(255),
IN first_name varchar(255),
IN last_name varchar(255),
IN from_date varchar(30),
IN to_date varchar(30),
IN token varchar(45),
OUT result varchar(255)
)
BEGIN

	DECLARE EXIT HANDLER FOR 1062 
    BEGIN
		ROLLBACK;
		DO RELEASE_LOCK('create_lock');
		SET result = 'Duplicate keys error encountered. Email or Token already found in the Database.';
    END;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		ROLLBACK;
		DO RELEASE_LOCK('create_lock');
		SET result = 'SQLException encountered in the Database';
    END;
    
	DO GET_LOCK('create_lock', 10);
       
		START TRANSACTION; 
        
            -- FIX:
            -- 1- THese sp for create or update need to only create or update
            --    tabla reservation - Single Responsible Principle
            
			call exists_reservation(from_date, to_date, -1, @ocupancies_count);

			IF @ocupancies_count = 0 THEN
				
				IF cust_id = -1 THEN
				
					call select_or_create_customer(email, first_name, last_name, @created_cust_id);
					
				ELSE
				
					SET @created_cust_id = cust_id;
					
				END IF;

				INSERT INTO `campsite_reservation-test`.`reservation` 
				(`token`, `customer_id`, `from_date`, `to_date`)
				VALUES (token, @created_cust_id, from_date, to_date);

				SET result = 'success';
				
			ELSE

				SET result = 'Some/all days from the intended Reservation dates were just booked in Database.';
				
			END IF;
        
		COMMIT;
    
    DO RELEASE_LOCK('create_lock');

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `delete_reservation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_reservation`(
IN cust_id bigint,
IN reserv_id bigint,
OUT result varchar(255)
)
BEGIN
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		ROLLBACK;
		SET result = 'SQLException encountered in the Database';
    END;

    DELETE FROM `campsite_reservation-test`.`reservation`
    WHERE (
	  `id` = reserv_id AND
	  `customer_id` = cust_id
	);
    
	SET result = 'success';
		
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `exists_reservation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `exists_reservation`(
IN from_date varchar(30),
IN to_date varchar(30),
IN reserv_id bigint,
OUT ocupancies_count int
)
BEGIN
DECLARE itself_count int;

DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'SQLException encountered';

	-- @ocupancies_count -- 
	SELECT COUNT(*) INTO ocupancies_count
	FROM reservation r 
	WHERE r.from_date BETWEEN from_date AND to_date 
	OR r.to_date > from_date AND r.to_date < to_date;

	IF ocupancies_count = 1 AND reserv_id <> -1 THEN
    
		-- check if not reserv_id itself
       	SELECT COUNT(*) INTO itself_count
		FROM reservation r 
		WHERE r.from_date BETWEEN from_date AND to_date 
		OR r.to_date > from_date AND r.to_date < to_date
        AND r.id = reserv_id;
        
        IF itself_count = 1 THEN
            -- reserv_id itself
			SELECT ocupancies_count = 0;	
        END IF;
        
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `select_or_create_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `select_or_create_customer`(
IN email varchar(255),
IN first_name varchar(255),
IN last_name varchar(255),
OUT cust_id bigint
)
BEGIN

	DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'SQLException encountered';

	SELECT id INTO cust_id
	FROM customer c 
	WHERE c.email = email;
	
    IF cust_id IS NULL THEN
    
		INSERT INTO `campsite_reservation-test`.`customer` 
		(`email`, `first_name`, `last_name`) 
		VALUES (email, first_name, last_name);
			
		SET cust_id = LAST_INSERT_ID();
        
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_reservation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_reservation`(
IN cust_id bigint,
IN reserv_id bigint,
IN email varchar(255),
IN first_name varchar(255),
IN last_name varchar(255),
IN from_date varchar(30),
IN to_date varchar(30),
OUT result varchar(255)
)
BEGIN
    
	DECLARE EXIT HANDLER FOR 1062 
    BEGIN
		ROLLBACK;
		SET result = 'Duplicate keys error encountered. Email or Token already found in the Database.';
    END;
    
	DECLARE EXIT HANDLER FOR 1452 
    BEGIN
		ROLLBACK;
		SET result = 'Customer does not exist.';
    END;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
		ROLLBACK;
		SET result = 'SQLException encountered in the Database.';
    END;
 
	DO GET_LOCK('create_lock', 10);
		
        START TRANSACTION; 
      
            -- FIX:
            -- 1- THese sp for create or update need to only create or update
            --    tabla reservation - Single Responsible Principle
			-- 2- Maybe sacar el update de customer fuera del lock y que se encargue
			--    MySQL del email key, no creo que se deba en el create_reservsation sp ????
            
			call exists_reservation(from_date, to_date, reserv_id, @ocupancies_count);

			UPDATE `campsite_reservation-test`.`customer` 
			SET   `email` = email, 
			 `first_name` = first_name, 
			  `last_name` = last_name 
			WHERE (`id` = cust_id); 
			
			IF @ocupancies_count = 0 THEN
			
				UPDATE `campsite_reservation-test`.`reservation` 
				SET `from_date` = from_date, 
                      `to_date` = to_date
			    -- security
				WHERE (`id` = reserv_id AND `customer_id` = cust_id);

				SET result = 'success';
				
			ELSE

				SET result = 'Customer info was update but some/all days from the intended Reservation dates were just booked in Database.';
				
			END IF;
    
		COMMIT;
        
    DO RELEASE_LOCK('create_lock');    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-01 20:17:37
