SELECT * FROM campsite_reservation.customer;
SELECT * FROM campsite_reservation.reservation;
SELECT count(*) FROM campsite_reservation.reservation;

call create_reservation (14, 'nine@nine.com', 'nine', 'nine', '2017-02-12', '2017-02-14', 'sdsdsd', @result);
Select @result;
-- '2017-01-01 00:00:11.763'

call exists_reservation('2017-01-01', '2017-02-14', -1, @ocupancies_count);
Select @ocupancies_count;

call exists_reservation('2017-01-05', '2017-01-06', 1223, @ocupancies_count);
Select @ocupancies_count;

-- no exisitng occupancies, create!!
call create_reservation (14, 'nine@nine.com', 'nine', 'nine', '2017-01-05', '2017-01-06', 'sdsdsd', @result);
Select @result;

UPDATE `campsite_reservation`.`customer` SET `email` = 'qaz@as.caam', `first_name` = 'Diegooa', `last_name` = 'Hidalgooa' WHERE (`id` = '1111111111111111111111');

call select_or_create_customer('ten@nine.com', 'ten', 'ten', @result);
Select @result;

SELECT * FROM campsite_reservation.customer;
SELECT * FROM campsite_reservation.reservation;

call create_reservation (-1, 'nine@nine.com', 'nine', 'nine', '2017-02-12', '2017-02-14', 'sdsdsd', @result);
Select @result;

SELECT r.from_date as fromDate, r.to_date as toDate 
FROM reservation r 
WHERE r.from_date BETWEEN '2016-12-01' AND '2019-12-31'
OR r.to_date > '2016-12-01' AND r.to_date <'2016-12-31'
ORDER BY fromDate;

DELETE FROM campsite_reservation.customer;

SELECT '2016-12-05' > '2016-12-01';

call update_reservation(185, 1464,'nine@nine.com','nine', 'nine', '2017-02-12','2017-02-14','sdsdsd', @result);
SELECT @result;

call update_reservation(-1, -1,'nine@nine.com','nine', 'nine', '2017-02-12','2017-02-14','sdsdsd', @result);
SELECT @result;

call create_reservation (972, 'abc@abc.com', 'firstName', 'lastName', '2019-02-01', '2019-02-03', 'sdsdsd', @result);
Select @result;